import os
import base64
from pathlib import Path
from datetime import datetime, timedelta
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
import json

# Import our modules
from src.data_generator import generate_enhanced_data
from src.huggingface_agent import HuggingFaceAPIAgent, HuggingFaceLlamaAgent, SimpleQAAgent, HF_AVAILABLE
from src.analysis import build_text_report, compute_kpis, detect_off_schedule_usage, estimate_standby_waste

# Page config
st.set_page_config(
    page_title="Harsha Motors - Energy Intelligence",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #E3F2FD 0%, #F5F5F5 100%);
        padding: 1rem;
        border-radius: 15px;
        margin-bottom: 2rem;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    
    .metric-card {
        background: linear-gradient(135deg, #E3F2FD 0%, #F8F9FA 100%);
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border-left: 5px solid #4A90E2;
        margin: 1rem 0;
        text-align: center;
        height: 140px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        min-height: 140px;
    }
    
    .metric-card h3 {
        margin: 0 0 0.5rem 0;
        font-size: 1rem;
        color: #2C3E50;
        font-weight: 600;
    }
    
    .metric-card h2 {
        margin: 0;
        font-size: 1.8rem;
        color: #4A90E2;
        font-weight: 700;
        line-height: 1.2;
    }
    
    .insight-card {
        background: linear-gradient(135deg, #FFF3E0 0%, #F8F9FA 100%);
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border-left: 5px solid #FF9800;
        margin: 1rem 0;
    }
    
    .drill-down-card {
        background: linear-gradient(135deg, #E8F5E8 0%, #F8F9FA 100%);
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border-left: 5px solid #4CAF50;
        margin: 1rem 0;
    }
    
    .qa-card {
        background: linear-gradient(135deg, #F3E5F5 0%, #F8F9FA 100%);
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border-left: 5px solid #9C27B0;
        margin: 1rem 0;
    }
    
    .filter-section {
        background: white;
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        margin-bottom: 1rem;
    }
    
    .stSelectbox > div > div {
        border-radius: 10px;
    }
    
    .stButton > button {
        border-radius: 25px;
        background: linear-gradient(90deg, #4A90E2, #357ABD);
        color: white;
        border: none;
        padding: 0.5rem 2rem;
        font-weight: 600;
    }
    
    .login-container {
        background: white;
        padding: 2rem;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        max-width: 400px;
        margin: 2rem auto;
    }
    
    .time-display {
        font-size: 1.2rem;
        font-weight: 600;
        color: #2C3E50;
        text-align: right;
        padding: 1rem;
    }
</style>
""", unsafe_allow_html=True)

# Authentication
def check_login(username, password):
    users = {
        "Admin": "admin",
        "User1": "admin"
    }
    return users.get(username) == password

def login_page():
    st.markdown('<div class="login-container">', unsafe_allow_html=True)
    
    # Logo - using text-based design
    st.markdown("""
    <div style="text-align: center; margin-bottom: 2rem;">
        <div style="display: inline-block; padding: 1.5rem; background: linear-gradient(135deg, #4A90E2, #357ABD); 
                    border-radius: 20px; color: white; box-shadow: 0 8px 25px rgba(0,0,0,0.2);">
            <h1 style="margin: 0; font-size: 2rem;">⚡ HARSHA MOTORS</h1>
            <p style="margin: 0.5rem 0 0 0; font-size: 1rem; opacity: 0.9;">Energy Intelligence Platform</p>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("### 🔐 Login to Harsha Motors Energy Intelligence")
    
    with st.form("login_form"):
        username = st.selectbox("Username", ["Admin", "User1"])
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login", use_container_width=True)
        
        if submit:
            if check_login(username, password):
                st.session_state.logged_in = True
                st.session_state.username = username
                st.rerun()
            else:
                st.error("Invalid credentials. Default password is 'admin'")
    
    st.markdown('</div>', unsafe_allow_html=True)

def create_header():
    """Create the main header with logo and time"""
    col1, col2, col3 = st.columns([2, 3, 2])
    
    with col1:
        # Use a simple text-based logo
        st.markdown("""
        <div style="margin-top: 1rem; padding: 1rem; background: linear-gradient(135deg, #4A90E2, #357ABD); 
                    border-radius: 15px; text-align: center; color: white; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
            <h2 style="margin: 0; font-size: 1.5rem;">⚡ HARSHA</h2>
            <p style="margin: 0; font-size: 0.9rem;">MOTORS</p>
            <small style="font-size: 0.7rem;">Energy Intelligence</small>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div style="text-align: center; padding: 1rem;">
            <h1 style="color: #2C3E50; margin: 0;">Harsha Motors</h1>
            <h3 style="color: #34495E; margin: 0;">Energy Intelligence Dashboard</h3>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        current_time = datetime.now()
        st.markdown(f"""
        <div class="time-display">
            📅 {current_time.strftime('%B %d, %Y')}<br>
            🕐 {current_time.strftime('%I:%M %p')}
        </div>
        """, unsafe_allow_html=True)

@st.cache_data
def load_enhanced_data():
    """Load or generate enhanced data"""
    try:
        # Generate fresh data
        energy_df, devices_df, schedules_df = generate_enhanced_data()
        
        # Validate data types and clean if necessary
        if 'timestamp' in energy_df.columns:
            energy_df['timestamp'] = pd.to_datetime(energy_df['timestamp'], errors='coerce')
            energy_df = energy_df.dropna(subset=['timestamp'])
        
        if 'energy_kwh' in energy_df.columns:
            energy_df['energy_kwh'] = pd.to_numeric(energy_df['energy_kwh'], errors='coerce')
            energy_df = energy_df.dropna(subset=['energy_kwh'])
        
        # Ensure we have valid data
        if energy_df.empty:
            st.error("No valid data could be generated. Please refresh the page.")
            st.stop()
            
        return energy_df, devices_df, schedules_df
        
    except Exception as e:
        st.error(f"Error loading data: {str(e)}")
        st.info("Generating minimal sample data...")
        
        # Fallback to minimal sample data
        current_time = datetime.now()
        sample_data = []
        
        for i in range(100):  # 100 sample records
            sample_data.append({
                'timestamp': current_time - timedelta(hours=i),
                'device_id': f'Device_{i%5 + 1:03d}',
                'energy_kwh': round(np.random.uniform(0.5, 5.0), 2),
                'department': f'Department {(i%5) + 1}',
                'device_type': 'Sample Device',
                'location': f'Zone {chr(65 + (i%3))}'
            })
        
        energy_df = pd.DataFrame(sample_data)
        devices_df = pd.DataFrame([
            {'device_id': f'Device_{i:03d}', 'device_type': 'Sample Device', 
             'location': f'Zone {chr(65 + (i%3))}', 'standby_kwh': 0.5, 
             'department': f'Department {i+1}'} 
            for i in range(5)
        ])
        schedules_df = pd.DataFrame([
            {'device_id': f'Device_{i:03d}', 'weekday': 'Mon-Fri', 
             'start_hour': 8, 'end_hour': 18} 
            for i in range(5)
        ])
        
        return energy_df, devices_df, schedules_df

def create_advanced_filters(energy_df):
    """Create advanced filtering options"""
    st.markdown("### 🔧 Advanced Filters")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        # Department filter
        departments = ['All'] + sorted(energy_df['department'].unique().tolist())
        selected_dept = st.selectbox("🏢 Department", departments, key="dept_filter")
    
    with col2:
        # Device type filter
        device_types = ['All'] + sorted(energy_df['device_type'].unique().tolist())
        selected_device_type = st.selectbox("🔧 Device Type", device_types, key="device_type_filter")
    
    with col3:
        # Location filter
        locations = ['All'] + sorted(energy_df['location'].unique().tolist())
        selected_location = st.selectbox("📍 Location", locations, key="location_filter")
    
    col4, col5, col6 = st.columns(3)
    
    with col4:
        # Consumption range filter
        min_consumption = float(energy_df['energy_kwh'].min())
        max_consumption = float(energy_df['energy_kwh'].max())
        consumption_range = st.slider(
            "⚡ Energy Range (kWh)", 
            min_consumption, max_consumption, 
            (min_consumption, max_consumption),
            key="consumption_filter"
        )
    
    with col5:
        # Time of day filter
        hour_range = st.slider("🕐 Hour Range", 0, 23, (0, 23), key="hour_filter")
    
    with col6:
        # Day of week filter
        days = ['All', 'Weekdays', 'Weekends', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        selected_day = st.selectbox("📅 Day Filter", days, key="day_filter")
    
    return {
        'department': selected_dept,
        'device_type': selected_device_type,
        'location': selected_location,
        'consumption_range': consumption_range,
        'hour_range': hour_range,
        'day_filter': selected_day
    }

def apply_filters(energy_df, filters):
    """Apply selected filters to the dataframe"""
    filtered_df = energy_df.copy()
    
    # Department filter
    if filters['department'] != 'All':
        filtered_df = filtered_df[filtered_df['department'] == filters['department']]
    
    # Device type filter
    if filters['device_type'] != 'All':
        filtered_df = filtered_df[filtered_df['device_type'] == filters['device_type']]
    
    # Location filter
    if filters['location'] != 'All':
        filtered_df = filtered_df[filtered_df['location'] == filters['location']]
    
    # Consumption range filter
    filtered_df = filtered_df[
        (filtered_df['energy_kwh'] >= filters['consumption_range'][0]) &
        (filtered_df['energy_kwh'] <= filters['consumption_range'][1])
    ]
    
    # Hour range filter
    filtered_df['hour'] = filtered_df['timestamp'].dt.hour
    filtered_df = filtered_df[
        (filtered_df['hour'] >= filters['hour_range'][0]) &
        (filtered_df['hour'] <= filters['hour_range'][1])
    ]
    
    # Day filter
    if filters['day_filter'] != 'All':
        filtered_df['day_name'] = filtered_df['timestamp'].dt.day_name()
        if filters['day_filter'] == 'Weekdays':
            filtered_df = filtered_df[filtered_df['timestamp'].dt.weekday < 5]
        elif filters['day_filter'] == 'Weekends':
            filtered_df = filtered_df[filtered_df['timestamp'].dt.weekday >= 5]
        elif filters['day_filter'] in ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']:
            filtered_df = filtered_df[filtered_df['day_name'] == filters['day_filter']]
    
    return filtered_df

def create_drill_down_view(energy_df, selection_data):
    """Create detailed drill-down view based on selection"""
    if not selection_data:
        return
    
    st.markdown("## 🔍 Drill-Down Analysis")
    
    # Parse selection data (this would come from plotly click events)
    st.markdown("""
    <div class="drill-down-card">
        <h4>📊 Detailed View</h4>
        <p>Click on any chart element to see detailed analysis here.</p>
        <p><em>Selected data will show device-specific trends, comparisons, and recommendations.</em></p>
    </div>
    """, unsafe_allow_html=True)
    
    # Show sample drill-down for demonstration
    if st.button("🔍 Show Sample Drill-Down"):
        sample_device = energy_df['device_id'].iloc[0]
        device_data = energy_df[energy_df['device_id'] == sample_device]
        
        st.markdown(f"### Detailed Analysis: {sample_device}")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Device trend over time
            daily_trend = device_data.groupby(device_data['timestamp'].dt.date)['energy_kwh'].sum().reset_index()
            daily_trend.columns = ['date', 'energy_kwh']
            
            fig_trend = px.line(daily_trend, x='date', y='energy_kwh',
                              title=f"{sample_device} - Daily Consumption Trend",
                              color_discrete_sequence=['#4A90E2'])
            st.plotly_chart(fig_trend, use_container_width=True)
        
        with col2:
            # Hourly pattern for this device
            hourly_pattern = device_data.groupby(device_data['timestamp'].dt.hour)['energy_kwh'].mean().reset_index()
            hourly_pattern.columns = ['hour', 'energy_kwh']
            
            fig_hourly = px.bar(hourly_pattern, x='hour', y='energy_kwh',
                               title=f"{sample_device} - Hourly Pattern",
                               color_discrete_sequence=['#357ABD'])
            st.plotly_chart(fig_hourly, use_container_width=True)
        
        # Device statistics
        st.markdown("#### 📈 Device Statistics")
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Consumption", f"{device_data['energy_kwh'].sum():.2f} kWh")
        with col2:
            st.metric("Average/Hour", f"{device_data['energy_kwh'].mean():.2f} kWh")
        with col3:
            st.metric("Peak Consumption", f"{device_data['energy_kwh'].max():.2f} kWh")
        with col4:
            st.metric("Efficiency Score", "85%")  # Sample score

def create_huggingface_qa(energy_df, devices_df):
    """Create Hugging Face Q&A interface"""
    st.markdown("## 🤖 AI-Powered Energy Assistant (Llama 3)")
    
    # Pre-configure API Key and Model
    if 'hf_api_key' not in st.session_state:
        st.session_state.hf_api_key = "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"
        st.session_state.selected_model = "meta-llama/Meta-Llama-3-8B-Instruct"
    
    # API Key configuration (collapsible)
    with st.expander("🔑 Hugging Face API Configuration", expanded=False):
        api_key = st.text_input(
            "Hugging Face API Key:",
            value=st.session_state.hf_api_key,
            type="password",
            help="API key is pre-configured for Llama 3"
        )
        
        model_options = [
            "meta-llama/Meta-Llama-3-8B-Instruct",
            "meta-llama/Meta-Llama-3-70B-Instruct", 
            "meta-llama/Llama-2-7b-chat-hf",
            "meta-llama/Llama-2-13b-chat-hf"
        ]
        
        current_model = st.session_state.get('selected_model', model_options[0])
        selected_model = st.selectbox(
            "Select Llama Model:",
            model_options,
            index=model_options.index(current_model) if current_model in model_options else 0,
            help="Llama 3-8B-Instruct is pre-configured for optimal performance"
        )
        
        if st.button("🔄 Update Configuration"):
            st.session_state.hf_api_key = api_key
            st.session_state.selected_model = selected_model
            # Clear existing agent to force reinitialization
            if 'qa_agent' in st.session_state:
                del st.session_state.qa_agent
            st.success("✅ Configuration updated! AI agent will reinitialize on next question.")
    
    # Show current configuration
    st.info(f"🤖 **Current AI Model:** {st.session_state.get('selected_model', 'meta-llama/Meta-Llama-3-8B-Instruct')} | **Status:** {'✅ Ready' if st.session_state.hf_api_key else '❌ No API Key'}")
    
    # Initialize Q&A agent
    if 'qa_agent' not in st.session_state and st.session_state.hf_api_key:
        try:
            with st.spinner("🤖 Initializing Llama 3 AI Agent..."):
                model_name = st.session_state.get('selected_model', model_options[0])
                st.session_state.qa_agent = HuggingFaceAPIAgent(
                    api_key=st.session_state.hf_api_key,
                    model_name=model_name
                )
                st.success(f"✅ Llama 3 AI Agent initialized with {model_name}!")
        except Exception as e:
            st.error(f"❌ Failed to initialize API agent: {str(e)}")
            st.session_state.qa_agent = SimpleQAAgent()
            st.info("🔄 Using simplified Q&A agent as fallback.")
    
    elif 'qa_agent' not in st.session_state:
        # No API key provided, use simple agent
        st.session_state.qa_agent = SimpleQAAgent()
        st.info("ℹ️ Using simplified Q&A agent. Enter your Hugging Face API key above for advanced AI capabilities.")
    
    # Set context with current data
    if 'qa_agent' in st.session_state:
        st.session_state.qa_agent.set_context(energy_df, devices_df)
    
    st.markdown("""
    <div class="qa-card">
        <h4>🧠 Ask Questions About Your Energy Data</h4>
        <p>Ask me anything about energy consumption, device performance, or optimization opportunities!</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Sample questions
    st.markdown("#### 💡 Sample Questions:")
    sample_questions = [
        "Which device consumes the most energy and what are the optimization opportunities?",
        "Analyze the peak consumption patterns and suggest load balancing strategies",
        "Provide a comprehensive energy cost reduction plan with specific recommendations",
        "Compare department-wise energy efficiency and identify improvement areas",
        "What are the seasonal energy consumption trends and how can we optimize for them?",
        "Identify devices with unusual consumption patterns and potential maintenance needs",
        "Calculate the ROI of implementing energy-efficient equipment upgrades",
        "Analyze the correlation between production schedules and energy consumption"
    ]
    
    col1, col2 = st.columns(2)
    with col1:
        for i, q in enumerate(sample_questions[:3]):
            if st.button(f"❓ {q}", key=f"sample_q_{i}"):
                st.session_state.current_question = q
    
    with col2:
        for i, q in enumerate(sample_questions[3:], 3):
            if st.button(f"❓ {q}", key=f"sample_q_{i}"):
                st.session_state.current_question = q
    
    # Question input
    question = st.text_area(
        "🔍 Your Question:",
        value=st.session_state.get('current_question', ''),
        placeholder="Ask detailed questions about energy consumption, optimization strategies, cost analysis, predictive maintenance, or any other energy-related insights...",
        height=100
    )
    
    col1, col2 = st.columns([3, 1])
    with col1:
        if st.button("🚀 Get AI Analysis", use_container_width=True) and question:
            with st.spinner("🤖 Llama 3 is analyzing your energy data..."):
                try:
                    answer = st.session_state.qa_agent.answer_question(question)
                    
                    st.markdown("#### 🎯 AI Analysis Results:")
                    
                    # Display the answer with better formatting
                    if isinstance(st.session_state.qa_agent, HuggingFaceAPIAgent):
                        st.markdown(f"""
                        <div style="background: linear-gradient(135deg, #f8f9fa 0%, #e3f2fd 100%); 
                                    padding: 1.5rem; border-radius: 15px; 
                                    border-left: 5px solid #4A90E2; margin: 1rem 0;
                                    box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
                            <div style="color: #2C3E50; line-height: 1.6;">
                                {answer.replace('\n', '<br>')}
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                        
                        # Show model info
                        model_name = st.session_state.get('selected_model', 'Unknown')
                        st.caption(f"🤖 Powered by {model_name}")
                    else:
                        st.markdown(f"""
                        <div style="background: #f8f9fa; padding: 1rem; border-radius: 10px; border-left: 4px solid #4A90E2;">
                            {answer}
                        </div>
                        """, unsafe_allow_html=True)
                    
                    # Clear the question
                    if 'current_question' in st.session_state:
                        del st.session_state.current_question
                        
                except Exception as e:
                    st.error(f"Error generating answer: {str(e)}")
    
    with col2:
        if st.button("🗑️ Clear", use_container_width=True):
            if 'current_question' in st.session_state:
                del st.session_state.current_question
            st.rerun()

def create_textual_reports(energy_df, devices_df, schedules_df):
    """Create comprehensive textual reports section"""
    st.markdown("## 📋 Comprehensive Energy Reports")
    
    st.markdown("""
    <div style="background: linear-gradient(135deg, #E8F5E8 0%, #F8F9FA 100%); 
                padding: 1.5rem; border-radius: 15px; 
                box-shadow: 0 4px 15px rgba(0,0,0,0.1); 
                border-left: 5px solid #4CAF50; margin: 1rem 0;">
        <h4>📊 Detailed Energy Analysis & Optimization Reports</h4>
        <p>Generate comprehensive textual reports with detailed analysis, recommendations, and actionable insights.</p>
    </div>
    """, unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📈 Generate Full Energy Report", use_container_width=True):
            with st.spinner("🔍 Analyzing energy data and generating comprehensive report..."):
                try:
                    report = build_text_report(energy_df, devices_df, schedules_df)
                    st.session_state.energy_report = report
                    st.success("✅ Comprehensive energy report generated!")
                except Exception as e:
                    st.error(f"Error generating report: {str(e)}")
    
    with col2:
        if st.button("💰 Cost Analysis Report", use_container_width=True):
            with st.spinner("💵 Generating cost analysis report..."):
                cost_report = generate_cost_report(energy_df, devices_df)
                st.session_state.cost_report = cost_report
                st.success("✅ Cost analysis report generated!")
    
    with col3:
        if st.button("🎯 Optimization Recommendations", use_container_width=True):
            with st.spinner("🔧 Generating optimization recommendations..."):
                optimization_report = generate_optimization_report(energy_df, devices_df)
                st.session_state.optimization_report = optimization_report
                st.success("✅ Optimization recommendations generated!")
    
    # Display reports
    if 'energy_report' in st.session_state:
        st.markdown("### 📊 Comprehensive Energy Analysis Report")
        
        col1, col2 = st.columns([4, 1])
        with col1:
            st.markdown("**Full Energy Analysis Report with Recommendations**")
        with col2:
            if st.button("📥 Download Report"):
                st.download_button(
                    label="📄 Download as Text File",
                    data=st.session_state.energy_report,
                    file_name=f"Harsha_Motors_Energy_Report_{pd.Timestamp.now().strftime('%Y%m%d_%H%M')}.txt",
                    mime="text/plain"
                )
        
        # Display report in a scrollable text area
        st.text_area(
            "Energy Analysis Report:",
            value=st.session_state.energy_report,
            height=600,
            help="Scroll to read the complete report. Use the download button to save as a file."
        )
    
    if 'cost_report' in st.session_state:
        st.markdown("### 💰 Cost Analysis Report")
        st.text_area(
            "Cost Analysis:",
            value=st.session_state.cost_report,
            height=400
        )
    
    if 'optimization_report' in st.session_state:
        st.markdown("### 🎯 Optimization Recommendations")
        st.text_area(
            "Optimization Report:",
            value=st.session_state.optimization_report,
            height=400
        )

def generate_cost_report(energy_df, devices_df):
    """Generate detailed cost analysis report"""
    report = []
    
    report.append("=" * 60)
    report.append("HARSHA MOTORS - COST ANALYSIS REPORT")
    report.append("=" * 60)
    report.append(f"Generated: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("")
    
    # Cost calculations
    total_consumption = energy_df['energy_kwh'].sum()
    total_cost = total_consumption * 100  # $100 per kWh
    monthly_cost = total_cost / 6  # 6 months of data
    
    report.append("COST SUMMARY")
    report.append("-" * 30)
    report.append(f"Total Energy Consumption: {total_consumption:,.2f} kWh")
    report.append(f"Total Energy Cost: ${total_cost:,.2f}")
    report.append(f"Average Monthly Cost: ${monthly_cost:,.2f}")
    report.append(f"Projected Annual Cost: ${monthly_cost * 12:,.2f}")
    report.append("")
    
    # Department-wise costs
    dept_consumption = energy_df.groupby('department')['energy_kwh'].sum()
    report.append("DEPARTMENT-WISE COST BREAKDOWN")
    report.append("-" * 40)
    for dept, consumption in dept_consumption.sort_values(ascending=False).items():
        cost = consumption * 100
        percentage = (consumption / total_consumption) * 100
        report.append(f"{dept}: ${cost:,.2f} ({percentage:.1f}%)")
    report.append("")
    
    # Peak hour cost analysis
    hourly_consumption = energy_df.groupby(energy_df['timestamp'].dt.hour)['energy_kwh'].sum()
    peak_hour = hourly_consumption.idxmax()
    peak_consumption = hourly_consumption[peak_hour]
    peak_cost = peak_consumption * 150  # Higher peak rate
    
    report.append("PEAK HOUR COST ANALYSIS")
    report.append("-" * 30)
    report.append(f"Peak Hour: {peak_hour}:00")
    report.append(f"Peak Consumption: {peak_consumption:,.2f} kWh")
    report.append(f"Peak Hour Cost: ${peak_cost:,.2f}")
    report.append("")
    
    # Cost optimization opportunities
    report.append("COST OPTIMIZATION OPPORTUNITIES")
    report.append("-" * 40)
    
    # Peak shifting savings
    off_peak_hour = hourly_consumption.idxmin()
    potential_shift = (peak_consumption - hourly_consumption[off_peak_hour]) * 0.3  # 30% shiftable
    shift_savings = potential_shift * 50 * 30  # $50 difference, 30 days
    
    report.append(f"1. Peak Load Shifting")
    report.append(f"   Potential Monthly Savings: ${shift_savings:,.2f}")
    report.append(f"   Annual Savings: ${shift_savings * 12:,.2f}")
    report.append("")
    
    # Efficiency improvements
    efficiency_savings = total_cost * 0.15  # 15% efficiency improvement
    report.append(f"2. Equipment Efficiency Improvements")
    report.append(f"   Potential Total Savings: ${efficiency_savings:,.2f}")
    report.append(f"   ROI Period: 12-18 months")
    report.append("")
    
    report.append("=" * 60)
    
    return "\n".join(report)

def generate_optimization_report(energy_df, devices_df):
    """Generate optimization recommendations report"""
    report = []
    
    report.append("=" * 70)
    report.append("HARSHA MOTORS - ENERGY OPTIMIZATION RECOMMENDATIONS")
    report.append("=" * 70)
    report.append(f"Generated: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("")
    
    # Priority recommendations
    report.append("PRIORITY 1 - IMMEDIATE ACTIONS (0-30 days)")
    report.append("-" * 50)
    
    # Top consumers
    top_devices = energy_df.groupby(['device_id', 'device_type'])['energy_kwh'].sum().sort_values(ascending=False).head(5)
    report.append("1. Focus on Top Energy Consumers:")
    for i, ((device_id, device_type), consumption) in enumerate(top_devices.items(), 1):
        report.append(f"   {i}. {device_id} ({device_type}): {consumption:,.2f} kWh")
        report.append(f"      → Schedule maintenance check")
        report.append(f"      → Review operational parameters")
        report.append(f"      → Consider efficiency upgrades")
    report.append("")
    
    # Peak hour management
    hourly_avg = energy_df.groupby(energy_df['timestamp'].dt.hour)['energy_kwh'].mean()
    peak_hour = hourly_avg.idxmax()
    low_hour = hourly_avg.idxmin()
    
    report.append("2. Peak Hour Load Management:")
    report.append(f"   Peak Hour: {peak_hour}:00 ({hourly_avg[peak_hour]:.2f} kWh avg)")
    report.append(f"   Low Hour: {low_hour}:00 ({hourly_avg[low_hour]:.2f} kWh avg)")
    report.append("   → Shift non-critical operations to off-peak hours")
    report.append("   → Implement smart scheduling systems")
    report.append("   → Set up automated load balancing")
    report.append("")
    
    # Department-specific recommendations
    dept_consumption = energy_df.groupby('department')['energy_kwh'].sum().sort_values(ascending=False)
    highest_dept = dept_consumption.index[0]
    
    report.append("PRIORITY 2 - SHORT-TERM IMPROVEMENTS (1-3 months)")
    report.append("-" * 55)
    report.append(f"3. Department-Specific Initiatives ({highest_dept}):")
    report.append("   → Implement energy awareness training")
    report.append("   → Install smart sensors and controls")
    report.append("   → Set department energy budgets")
    report.append("   → Regular energy audits")
    report.append("")
    
    report.append("4. Equipment Optimization:")
    report.append("   → Upgrade to energy-efficient motors")
    report.append("   → Install variable frequency drives (VFDs)")
    report.append("   → Implement power factor correction")
    report.append("   → Regular calibration of energy meters")
    report.append("")
    
    # Long-term strategies
    report.append("PRIORITY 3 - LONG-TERM STRATEGIES (3-12 months)")
    report.append("-" * 52)
    report.append("5. Advanced Energy Management:")
    report.append("   → Deploy AI-powered predictive analytics")
    report.append("   → Implement automated demand response")
    report.append("   → Install renewable energy sources")
    report.append("   → Develop energy management ISO 50001 certification")
    report.append("")
    
    report.append("6. Technology Upgrades:")
    report.append("   → Smart building management systems")
    report.append("   → IoT-enabled equipment monitoring")
    report.append("   → Energy storage systems")
    report.append("   → Advanced metering infrastructure")
    report.append("")
    
    # ROI calculations
    total_consumption = energy_df['energy_kwh'].sum()
    potential_savings = total_consumption * 0.25 * 100  # 25% savings potential
    
    report.append("RETURN ON INVESTMENT ANALYSIS")
    report.append("-" * 40)
    report.append(f"Total Potential Annual Savings: ${potential_savings * 2:,.2f}")
    report.append(f"Estimated Implementation Cost: $75,000")
    report.append(f"Payback Period: 8-12 months")
    report.append(f"5-Year Net Savings: ${potential_savings * 10 - 75000:,.2f}")
    report.append("")
    
    report.append("=" * 70)
    
    return "\n".join(report)

def main_dashboard():
    """Main dashboard content"""
    create_header()
    
    # Load data
    energy_df, devices_df, schedules_df = load_enhanced_data()
    
    # Sidebar controls
    st.sidebar.markdown("### ⚙️ Dashboard Controls")
    
    # Date range filter (last 6 months by default)
    max_date = energy_df['timestamp'].max().date()
    min_date = (energy_df['timestamp'].max() - timedelta(days=180)).date()
    
    date_range = st.sidebar.date_input(
        "📅 Date Range",
        value=(min_date, max_date),
        min_value=energy_df['timestamp'].min().date(),
        max_value=max_date
    )
    
    # Unit toggle
    unit_toggle = st.sidebar.radio("💰 Display Units", ["kWh", "$ (USD)"])
    conversion_rate = 100  # $100 per kWh
    
    # Advanced filters
    with st.sidebar.expander("🔧 Advanced Filters", expanded=True):
        filters = create_advanced_filters(energy_df)
    
    # Logout button
    if st.sidebar.button("🚪 Logout"):
        st.session_state.logged_in = False
        st.session_state.username = None
        st.rerun()
    
    # Apply date filter
    if len(date_range) == 2:
        start_date, end_date = date_range
        energy_df = energy_df[
            (energy_df['timestamp'].dt.date >= start_date) &
            (energy_df['timestamp'].dt.date <= end_date)
        ]
    
    # Apply advanced filters
    filtered_df = apply_filters(energy_df, filters)
    
    if filtered_df.empty:
        st.warning("⚠️ No data matches the selected filters. Please adjust your filter criteria.")
        return
    
    # Apply unit conversion
    value_col = 'energy_kwh'
    unit_label = 'kWh'
    if unit_toggle == "$ (USD)":
        filtered_df['energy_usd'] = filtered_df['energy_kwh'] * conversion_rate
        value_col = 'energy_usd'
        unit_label = 'USD'
    
    # Main metrics
    st.markdown("## 📊 Key Performance Indicators")
    
    col1, col2, col3, col4 = st.columns(4)
    
    total_consumption = filtered_df[value_col].sum()
    avg_consumption = filtered_df.groupby('device_id')[value_col].sum().mean()
    active_devices = filtered_df['device_id'].nunique()
    peak_hour = filtered_df.groupby(filtered_df['timestamp'].dt.hour)[value_col].sum().idxmax()
    
    with col1:
        st.markdown(f"""
        <div class="metric-card">
            <h3>⚡ Total Consumption</h3>
            <h2>{total_consumption:,.1f} {unit_label}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="metric-card">
            <h3>📈 Avg per Device</h3>
            <h2>{avg_consumption:,.1f} {unit_label}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="metric-card">
            <h3>🔌 Active Devices</h3>
            <h2>{active_devices}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown(f"""
        <div class="metric-card">
            <h3>⏰ Peak Hour</h3>
            <h2>{peak_hour}:00</h2>
        </div>
        """, unsafe_allow_html=True)
    
    # Interactive Charts
    st.markdown("## 📈 Interactive Energy Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Time series chart with click events
        daily_consumption = filtered_df.groupby(filtered_df['timestamp'].dt.date)[value_col].sum().reset_index()
        daily_consumption.columns = ['date', value_col]
        
        fig_time = px.line(daily_consumption, x='date', y=value_col,
                          title=f"Daily Energy Consumption ({unit_label})",
                          color_discrete_sequence=['#4A90E2'])
        fig_time.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font=dict(color='#2C3E50')
        )
        
        # Enable click events
        selected_points = st.plotly_chart(fig_time, use_container_width=True, 
                                        on_select="rerun", selection_mode="points")
    
    with col2:
        # Department breakdown pie chart
        dept_consumption = filtered_df.groupby('department')[value_col].sum().reset_index()
        
        fig_dept = px.pie(dept_consumption, values=value_col, names='department',
                         title=f"Consumption by Department ({unit_label})",
                         color_discrete_sequence=px.colors.qualitative.Set3)
        fig_dept.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font=dict(color='#2C3E50')
        )
        st.plotly_chart(fig_dept, use_container_width=True)
    
    # Device-level analysis
    st.markdown("### 🔍 Device-Level Analysis")
    device_consumption = filtered_df.groupby(['device_id', 'device_type', 'department'])[value_col].sum().reset_index()
    device_consumption = device_consumption.sort_values(value_col, ascending=False).head(10)
    
    fig_devices = px.bar(device_consumption, x='device_id', y=value_col,
                        color='department',
                        title=f"Top 10 Energy Consuming Devices ({unit_label})",
                        hover_data=['device_type'])
    fig_devices.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color='#2C3E50'),
        xaxis_tickangle=-45
    )
    st.plotly_chart(fig_devices, use_container_width=True)
    
    # Drill-down analysis
    create_drill_down_view(filtered_df, selected_points if 'selected_points' in locals() else None)
    
    # Hugging Face Q&A
    create_huggingface_qa(filtered_df, devices_df)
    
    # Textual Reports
    create_textual_reports(filtered_df, devices_df, schedules_df)
    
    # Data table
    st.markdown("## 📋 Detailed Data View")
    
    if st.checkbox("Show detailed device data"):
        detailed_view = filtered_df.groupby(['device_id', 'device_type', 'department', 'location']).agg({
            value_col: ['sum', 'mean', 'max'],
            'timestamp': 'count'
        }).round(2)
        detailed_view.columns = [f'{col[1].title()} {unit_label}' if col[0] == value_col else 'Data Points' 
                               for col in detailed_view.columns]
        detailed_view = detailed_view.reset_index()
        st.dataframe(detailed_view, use_container_width=True)

def main():
    """Main application entry point"""
    # Initialize session state
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
    if 'username' not in st.session_state:
        st.session_state.username = None
    
    # Show login or dashboard
    if not st.session_state.logged_in:
        login_page()
    else:
        main_dashboard()

if __name__ == "__main__":
    main()
