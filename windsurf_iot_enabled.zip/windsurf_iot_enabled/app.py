import os
from pathlib import Path
import pandas as pd
import streamlit as st
import plotly.express as px

from src.analysis import (
    load_data,
    compute_kpis,
    detect_off_schedule_usage,
    estimate_standby_waste,
    detect_anomalies_zscore,
    build_text_report,
)

#arpit code

from langchain_openai import ChatOpenAI 
import os 
import httpx 
client = httpx.Client(verify=False)
llm = ChatOpenAI(base_url = "https://genailab.tcs.in",model = "azure_ai/genailab-maas-DeepSeek-V3-0324",api_key ="sk-TP5rN_u6j9mMszgVzFLGHA",http_client = client)
#llm.invoke("Hi")
#arpit code

# Optional Q&A agent
AGENT_AVAILABLE = False
try:
    from src.agent import QAAgent  # type: ignore
    AGENT_AVAILABLE = True
except Exception:
    AGENT_AVAILABLE = False

st.set_page_config(page_title="IoT Energy Optimization Agent", page_icon="⚡", layout="wide")

st.title("⚡ IoT Energy Consumption Optimization Agent")
st.caption("Analyze IoT device energy usage, detect inefficiencies, and get optimization recommendations.")

# Sidebar: Data selection
st.sidebar.header("Data Sources")
base_path = Path(__file__).parent
sample_logs = base_path / "data" / "energy_logs.csv"
sample_meta = base_path / "data" / "device_metadata.csv"
sample_sched = base_path / "data" / "operational_schedules.csv"

logs_file = st.sidebar.file_uploader("Energy logs CSV", type=["csv"], key="logs")
meta_file = st.sidebar.file_uploader("Device metadata CSV", type=["csv"], key="meta")
sched_file = st.sidebar.file_uploader("Operational schedules CSV", type=["csv"], key="sched")

use_sample = st.sidebar.checkbox("Use bundled sample data", value=True)

@st.cache_data(show_spinner=False)
def read_data(logs_src, meta_src, sched_src):
    if isinstance(logs_src, (str, Path)):
        logs_p = str(logs_src)
    else:
        logs_p = logs_src
    if isinstance(meta_src, (str, Path)):
        meta_p = str(meta_src)
    else:
        meta_p = meta_src
    if isinstance(sched_src, (str, Path)):
        sched_p = str(sched_src)
    else:
        sched_p = sched_src

    if hasattr(logs_p, "read"):
        logs = pd.read_csv(logs_p)
    else:
        logs = pd.read_csv(logs_p)
    if hasattr(meta_p, "read"):
        meta = pd.read_csv(meta_p)
    else:
        meta = pd.read_csv(meta_p)
    if hasattr(sched_p, "read"):
        sched = pd.read_csv(sched_p)
    else:
        sched = pd.read_csv(sched_p)

    logs['timestamp'] = pd.to_datetime(logs['timestamp'])
    logs['hour'] = logs['timestamp'].dt.hour
    logs['weekday'] = logs['timestamp'].dt.day_name()

    return logs, meta, sched

# Decide data sources
if use_sample:
    logs_src, meta_src, sched_src = sample_logs, sample_meta, sample_sched
else:
    logs_src = logs_file if logs_file is not None else sample_logs
    meta_src = meta_file if meta_file is not None else sample_meta
    sched_src = sched_file if sched_file is not None else sample_sched

# Load data
try:
    logs, meta, sched = read_data(logs_src, meta_src, sched_src)
except Exception as e:
    st.error(f"Failed to load data: {e}")
    st.stop()

# Overview metrics
kpis = compute_kpis(logs)
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Energy (kWh)", f"{kpis['total_kwh']:.2f}")
col2.metric("Avg per Device (kWh)", f"{kpis['avg_kwh_per_device']:.2f}")
col3.metric("Peak Hour", f"{kpis['peak_hour'] if kpis['peak_hour']>=0 else '-'}")
col4.metric("Peak Hour kWh", f"{kpis['peak_hour_kwh']:.2f}")

# Charts
st.subheader("Consumption Over Time")
logs_sorted = logs.sort_values("timestamp")
fig_time = px.line(logs_sorted, x="timestamp", y="energy_kwh", color="device_id", markers=True)
fig_time.update_layout(height=380, legend_title_text="Device")
st.plotly_chart(fig_time, use_container_width=True)

st.subheader("Total Consumption by Device")
by_device = logs.groupby('device_id')['energy_kwh'].sum().reset_index().sort_values('energy_kwh', ascending=False)
fig_dev = px.bar(by_device, x='device_id', y='energy_kwh', color='device_id', text=by_device['energy_kwh'].round(2))
fig_dev.update_traces(textposition='outside')
fig_dev.update_layout(height=380, showlegend=False)
st.plotly_chart(fig_dev, use_container_width=True)

# Off-schedule usage
st.subheader("Off-Schedule Usage")
off_sched = detect_off_schedule_usage(logs, sched)
if off_sched.empty:
    st.success("No off-schedule usage detected in the selected timeframe.")
else:
    st.warning(f"Detected {off_sched['energy_kwh'].sum():.2f} kWh off-schedule across {off_sched['device_id'].nunique()} devices.")
    st.dataframe(off_sched.sort_values(['device_id', 'timestamp']))

# Standby waste
st.subheader("Estimated Standby Waste")
standby = estimate_standby_waste(logs, meta)
if standby.empty:
    st.info("Insufficient metadata to estimate standby waste.")
else:
    st.dataframe(standby)

# Anomalies
st.subheader("Anomalies (Z-score ≥ 2.0)")
anoms = detect_anomalies_zscore(logs)
if anoms.empty:
    st.success("No anomalies detected.")
else:
    st.dataframe(anoms)

# Text report
st.subheader("Textual Report & Recommendations")
report = build_text_report(logs, meta, sched)
st.text(report)

# Q&A Section
st.subheader("Ask Questions About Your Energy Data (LLM-powered)")
if AGENT_AVAILABLE and os.getenv("OPENAI_API_KEY"):
    with st.expander("Open Q&A"):
        st.caption("Powered by LangChain + OpenAI. We index the generated report and summary snippets.")
        agent = QAAgent()
        # Build context: report + per-device summaries
        per_dev_summary = []
        for d, total in by_device.itertuples(index=False):
            per_dev_summary.append(f"Device {d} total: {total:.2f} kWh")
        context_texts = [report] + per_dev_summary
        try:
            agent.build_index(context_texts)
            query = st.text_input("Your question", placeholder="e.g., Which device has the most off-schedule usage?")
            if query:
                with st.spinner("Thinking..."):
                    answer = agent.answer(query)
                st.markdown(f"**Answer:** {answer}")
        except Exception as e:
            st.error(f"Q&A initialization failed: {e}")
else:
    st.info("Set OPENAI_API_KEY in your environment to enable LLM Q&A (optional).")

st.caption("Tip: Upload your own CSVs in the sidebar or uncheck 'Use bundled sample data'.")
