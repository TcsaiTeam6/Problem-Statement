import os
import base64
from pathlib import Path
from datetime import datetime, timedelta
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np

# Import our modules
from src.data_generator import generate_enhanced_data
from src.analysis import (
    compute_kpis,
    detect_off_schedule_usage,
    estimate_standby_waste,
    detect_anomalies_zscore,
    build_text_report,
)

# Page config
st.set_page_config(
    page_title="Harsha Motors - Energy Intelligence",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #E3F2FD 0%, #F5F5F5 100%);
        padding: 1rem;
        border-radius: 15px;
        margin-bottom: 2rem;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    
    .metric-card {
        background: linear-gradient(135deg, #E3F2FD 0%, #F8F9FA 100%);
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border: 1px solid #E1E8ED;
        margin: 0.5rem 0;
    }
    
    .insight-card {
        background: linear-gradient(135deg, #FFF3E0 0%, #F8F9FA 100%);
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border-left: 5px solid #FF9800;
        margin: 1rem 0;
    }
    
    .seasonal-card {
        background: linear-gradient(135deg, #E8F5E8 0%, #F8F9FA 100%);
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border-left: 5px solid #4CAF50;
        margin: 1rem 0;
    }
    
    .stSelectbox > div > div {
        border-radius: 10px;
    }
    
    .stButton > button {
        border-radius: 25px;
        background: linear-gradient(90deg, #4A90E2, #357ABD);
        color: white;
        border: none;
        padding: 0.5rem 2rem;
        font-weight: 600;
    }
    
    .login-container {
        background: white;
        padding: 2rem;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        max-width: 400px;
        margin: 2rem auto;
    }
    
    .time-display {
        font-size: 1.2rem;
        font-weight: 600;
        color: #2C3E50;
        text-align: right;
        padding: 1rem;
    }
</style>
""", unsafe_allow_html=True)

# Authentication
def check_login(username, password):
    users = {
        "Admin": "admin",
        "User1": "admin"
    }
    return users.get(username) == password

def login_page():
    st.markdown('<div class="login-container">', unsafe_allow_html=True)
    
    # Logo - using text-based design instead of SVG
    st.markdown("""
    <div style="text-align: center; margin-bottom: 2rem;">
        <div style="display: inline-block; padding: 1.5rem; background: linear-gradient(135deg, #4A90E2, #357ABD); 
                    border-radius: 20px; color: white; box-shadow: 0 8px 25px rgba(0,0,0,0.2);">
            <h1 style="margin: 0; font-size: 2rem;">⚡ HARSHA MOTORS</h1>
            <p style="margin: 0.5rem 0 0 0; font-size: 1rem; opacity: 0.9;">Energy Intelligence Platform</p>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("### 🔐 Login to Harsha Motors Energy Intelligence")
    
    with st.form("login_form"):
        username = st.selectbox("Username", ["Admin", "User1"])
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login", use_container_width=True)
        
        if submit:
            if check_login(username, password):
                st.session_state.logged_in = True
                st.session_state.username = username
                st.rerun()
            else:
                st.error("Invalid credentials. Default password is 'admin'")
    
    st.markdown('</div>', unsafe_allow_html=True)

def create_header():
    """Create the main header with logo and time"""
    col1, col2, col3 = st.columns([2, 3, 2])
    
    with col1:
        # Use a simple text-based logo instead of SVG to avoid rendering issues
        st.markdown("""
        <div style="margin-top: 1rem; padding: 1rem; background: linear-gradient(135deg, #4A90E2, #357ABD); 
                    border-radius: 15px; text-align: center; color: white; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
            <h2 style="margin: 0; font-size: 1.5rem;">⚡ HARSHA</h2>
            <p style="margin: 0; font-size: 0.9rem;">MOTORS</p>
            <small style="font-size: 0.7rem;">Energy Intelligence</small>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div style="text-align: center; padding: 1rem;">
            <h1 style="color: #2C3E50; margin: 0;">Harsha Motors</h1>
            <h3 style="color: #34495E; margin: 0;">Energy Intelligence Dashboard</h3>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        current_time = datetime.now()
        st.markdown(f"""
        <div class="time-display">
            📅 {current_time.strftime('%B %d, %Y')}<br>
            🕐 {current_time.strftime('%I:%M %p')}
        </div>
        """, unsafe_allow_html=True)

@st.cache_data
def load_enhanced_data():
    """Load or generate enhanced data"""
    try:
        # Generate fresh data to avoid parsing issues
        energy_df, devices_df, schedules_df = generate_enhanced_data()
        
        # Validate data types and clean if necessary
        if 'timestamp' in energy_df.columns:
            energy_df['timestamp'] = pd.to_datetime(energy_df['timestamp'], errors='coerce')
            energy_df = energy_df.dropna(subset=['timestamp'])
        
        if 'energy_kwh' in energy_df.columns:
            energy_df['energy_kwh'] = pd.to_numeric(energy_df['energy_kwh'], errors='coerce')
            energy_df = energy_df.dropna(subset=['energy_kwh'])
        
        # Ensure we have valid data
        if energy_df.empty:
            st.error("No valid data could be generated. Please refresh the page.")
            st.stop()
            
        return energy_df, devices_df, schedules_df
        
    except Exception as e:
        st.error(f"Error loading data: {str(e)}")
        st.info("Generating minimal sample data...")
        
        # Fallback to minimal sample data
        from datetime import datetime, timedelta
        import random
        
        # Create minimal sample data
        current_time = datetime.now()
        sample_data = []
        
        for i in range(100):  # 100 sample records
            sample_data.append({
                'timestamp': current_time - timedelta(hours=i),
                'device_id': f'Device_{i%5 + 1:03d}',
                'energy_kwh': round(random.uniform(0.5, 5.0), 2),
                'department': f'Department {(i%5) + 1}',
                'device_type': 'Sample Device',
                'location': f'Zone {chr(65 + (i%3))}'
            })
        
        energy_df = pd.DataFrame(sample_data)
        devices_df = pd.DataFrame([
            {'device_id': f'Device_{i:03d}', 'device_type': 'Sample Device', 
             'location': f'Zone {chr(65 + (i%3))}', 'standby_kwh': 0.5, 
             'department': f'Department {i+1}'} 
            for i in range(5)
        ])
        schedules_df = pd.DataFrame([
            {'device_id': f'Device_{i:03d}', 'weekday': 'Mon-Fri', 
             'start_hour': 8, 'end_hour': 18} 
            for i in range(5)
        ])
        
        return energy_df, devices_df, schedules_df

def create_actionable_insights(energy_df):
    """Generate actionable insights"""
    st.markdown("## 💡 Actionable Insights")
    
    # Calculate recent trends (last 4 weeks vs previous 4 weeks)
    recent_date = energy_df['timestamp'].max()
    last_4_weeks = energy_df[energy_df['timestamp'] >= recent_date - timedelta(weeks=4)]
    prev_4_weeks = energy_df[
        (energy_df['timestamp'] >= recent_date - timedelta(weeks=8)) &
        (energy_df['timestamp'] < recent_date - timedelta(weeks=4))
    ]
    
    # Group by device and calculate average consumption
    recent_avg = last_4_weeks.groupby('device_id')['energy_kwh'].mean()
    prev_avg = prev_4_weeks.groupby('device_id')['energy_kwh'].mean()
    
    # Calculate percentage change
    change_df = pd.DataFrame({
        'recent_avg': recent_avg,
        'prev_avg': prev_avg
    }).fillna(0)
    
    change_df['pct_change'] = ((change_df['recent_avg'] - change_df['prev_avg']) / 
                              change_df['prev_avg'].replace(0, 1)) * 100
    
    # Get top increasing consumers
    top_increases = change_df.nlargest(5, 'pct_change')
    
    insights = []
    for device_id, row in top_increases.iterrows():
        if row['pct_change'] > 10:  # Only show significant increases
            device_info = energy_df[energy_df['device_id'] == device_id].iloc[0]
            insights.append({
                'device': device_id,
                'department': device_info['department'],
                'increase': row['pct_change'],
                'recent_avg': row['recent_avg']
            })
    
    if insights:
        for insight in insights:
            st.markdown(f"""
            <div class="insight-card">
                <h4>⚠️ {insight['device']} - {insight['department']}</h4>
                <p><strong>Energy consumption increased by {insight['increase']:.1f}%</strong> in the last 4 weeks</p>
                <p>Current average: {insight['recent_avg']:.2f} kWh/hour</p>
                <p><em>Recommendation: Schedule maintenance check and review operational parameters</em></p>
            </div>
            """, unsafe_allow_html=True)
    else:
        st.success("✅ No significant energy consumption increases detected in recent weeks")

def create_seasonality_analysis(energy_df):
    """Create seasonality analysis"""
    st.markdown("## 📊 Seasonality Analysis")
    
    # Hourly patterns
    energy_df['hour'] = energy_df['timestamp'].dt.hour
    energy_df['day_of_week'] = energy_df['timestamp'].dt.day_name()
    energy_df['month'] = energy_df['timestamp'].dt.month
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div class="seasonal-card">
            <h4>🕐 Hourly Consumption Patterns</h4>
        </div>
        """, unsafe_allow_html=True)
        
        hourly_pattern = energy_df.groupby('hour')['energy_kwh'].mean().reset_index()
        fig_hourly = px.line(hourly_pattern, x='hour', y='energy_kwh',
                           title="Average Energy Consumption by Hour",
                           color_discrete_sequence=['#4A90E2'])
        fig_hourly.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font=dict(color='#2C3E50')
        )
        st.plotly_chart(fig_hourly, use_container_width=True)
    
    with col2:
        st.markdown("""
        <div class="seasonal-card">
            <h4>📅 Weekly Consumption Patterns</h4>
        </div>
        """, unsafe_allow_html=True)
        
        daily_pattern = energy_df.groupby('day_of_week')['energy_kwh'].mean().reset_index()
        # Reorder days
        day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        daily_pattern['day_of_week'] = pd.Categorical(daily_pattern['day_of_week'], categories=day_order)
        daily_pattern = daily_pattern.sort_values('day_of_week')
        
        fig_daily = px.bar(daily_pattern, x='day_of_week', y='energy_kwh',
                          title="Average Energy Consumption by Day",
                          color_discrete_sequence=['#357ABD'])
        fig_daily.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font=dict(color='#2C3E50')
        )
        st.plotly_chart(fig_daily, use_container_width=True)

def main_dashboard():
    """Main dashboard content"""
    create_header()
    
    # Load data
    energy_df, devices_df, schedules_df = load_enhanced_data()
    
    # Sidebar filters
    st.sidebar.markdown("### 🔧 Filters & Controls")
    
    # Department filter
    departments = ['All'] + sorted(energy_df['department'].unique().tolist())
    selected_dept = st.sidebar.selectbox("Department", departments)
    
    # Date range filter (last 6 months by default)
    max_date = energy_df['timestamp'].max().date()
    min_date = (energy_df['timestamp'].max() - timedelta(days=180)).date()
    
    date_range = st.sidebar.date_input(
        "Date Range",
        value=(min_date, max_date),
        min_value=energy_df['timestamp'].min().date(),
        max_value=max_date
    )
    
    # Unit toggle
    unit_toggle = st.sidebar.radio("Display Units", ["kWh", "$ (USD)"])
    conversion_rate = 100  # $100 per kWh
    
    # Logout button
    if st.sidebar.button("🚪 Logout"):
        st.session_state.logged_in = False
        st.session_state.username = None
        st.rerun()
    
    # Filter data
    filtered_df = energy_df.copy()
    if selected_dept != 'All':
        filtered_df = filtered_df[filtered_df['department'] == selected_dept]
    
    if len(date_range) == 2:
        start_date, end_date = date_range
        filtered_df = filtered_df[
            (filtered_df['timestamp'].dt.date >= start_date) &
            (filtered_df['timestamp'].dt.date <= end_date)
        ]
    
    # Apply unit conversion
    value_col = 'energy_kwh'
    unit_label = 'kWh'
    if unit_toggle == "$ (USD)":
        filtered_df['energy_usd'] = filtered_df['energy_kwh'] * conversion_rate
        value_col = 'energy_usd'
        unit_label = 'USD'
    
    # Main metrics
    st.markdown("## 📊 Key Performance Indicators")
    
    col1, col2, col3, col4 = st.columns(4)
    
    total_consumption = filtered_df[value_col].sum()
    avg_consumption = filtered_df.groupby('device_id')[value_col].sum().mean()
    active_devices = filtered_df['device_id'].nunique()
    peak_hour = filtered_df.groupby(filtered_df['timestamp'].dt.hour)[value_col].sum().idxmax()
    
    with col1:
        st.markdown(f"""
        <div class="metric-card">
            <h3>⚡ Total Consumption</h3>
            <h2>{total_consumption:,.1f} {unit_label}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="metric-card">
            <h3>📈 Avg per Device</h3>
            <h2>{avg_consumption:,.1f} {unit_label}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="metric-card">
            <h3>🔌 Active Devices</h3>
            <h2>{active_devices}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown(f"""
        <div class="metric-card">
            <h3>⏰ Peak Hour</h3>
            <h2>{peak_hour}:00</h2>
        </div>
        """, unsafe_allow_html=True)
    
    # Charts with drill-down
    st.markdown("## 📈 Energy Consumption Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Time series chart
        daily_consumption = filtered_df.groupby(filtered_df['timestamp'].dt.date)[value_col].sum().reset_index()
        daily_consumption.columns = ['date', value_col]
        
        fig_time = px.line(daily_consumption, x='date', y=value_col,
                          title=f"Daily Energy Consumption ({unit_label})",
                          color_discrete_sequence=['#4A90E2'])
        fig_time.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font=dict(color='#2C3E50')
        )
        
        # Add click event handling
        selected_point = st.plotly_chart(fig_time, use_container_width=True, 
                                       on_select="rerun", selection_mode="points")
    
    with col2:
        # Department breakdown
        dept_consumption = filtered_df.groupby('department')[value_col].sum().reset_index()
        
        fig_dept = px.pie(dept_consumption, values=value_col, names='department',
                         title=f"Consumption by Department ({unit_label})",
                         color_discrete_sequence=px.colors.qualitative.Set3)
        fig_dept.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font=dict(color='#2C3E50')
        )
        st.plotly_chart(fig_dept, use_container_width=True)
    
    # Device-level analysis
    st.markdown("### 🔍 Device-Level Analysis")
    device_consumption = filtered_df.groupby(['device_id', 'device_type', 'department'])[value_col].sum().reset_index()
    device_consumption = device_consumption.sort_values(value_col, ascending=False).head(10)
    
    fig_devices = px.bar(device_consumption, x='device_id', y=value_col,
                        color='department',
                        title=f"Top 10 Energy Consuming Devices ({unit_label})",
                        hover_data=['device_type'])
    fig_devices.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color='#2C3E50'),
        xaxis_tickangle=-45
    )
    st.plotly_chart(fig_devices, use_container_width=True)
    
    # Actionable Insights
    create_actionable_insights(filtered_df)
    
    # Seasonality Analysis
    create_seasonality_analysis(filtered_df)
    
    # Data table with drill-down
    st.markdown("## 📋 Detailed Data View")
    
    if st.checkbox("Show detailed device data"):
        detailed_view = filtered_df.groupby(['device_id', 'device_type', 'department', 'location']).agg({
            value_col: ['sum', 'mean', 'max'],
            'timestamp': 'count'
        }).round(2)
        detailed_view.columns = [f'{col[1].title()} {unit_label}' if col[0] == value_col else 'Data Points' 
                               for col in detailed_view.columns]
        detailed_view = detailed_view.reset_index()
        st.dataframe(detailed_view, use_container_width=True)

def main():
    """Main application entry point"""
    # Initialize session state
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
    if 'username' not in st.session_state:
        st.session_state.username = None
    
    # Show login or dashboard
    if not st.session_state.logged_in:
        login_page()
    else:
        main_dashboard()

if __name__ == "__main__":
    main()
