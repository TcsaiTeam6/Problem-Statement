// Array of encouraging messages
const messages = [
    "🎉 Great job! You clicked the button!",
    "✨ Welcome to the world of web development!",
    "🚀 You're on your way to building amazing things!",
    "💡 Every expert was once a beginner!",
    "🌟 Keep exploring and learning!",
    "🎯 You've got this! Keep coding!",
    "🔥 Awesome! You're interacting with JavaScript!"
];

let clickCount = 0;

function showMessage() {
    const messageElement = document.getElementById('message');
    const button = document.querySelector('.interactive-btn');
    
    clickCount++;
    
    // Get a random message or cycle through them
    const messageIndex = (clickCount - 1) % messages.length;
    const selectedMessage = messages[messageIndex];
    
    // Update the message content
    messageElement.textContent = selectedMessage;
    
    // Show the message with animation
    messageElement.classList.add('show');
    
    // Add some visual feedback to the button
    button.style.transform = 'scale(0.95)';
    setTimeout(() => {
        button.style.transform = '';
    }, 150);
    
    // Change button text after first click
    if (clickCount === 1) {
        button.textContent = 'Click again!';
    } else if (clickCount > 5) {
        button.textContent = 'You\'re persistent! 😄';
    }
}

// Add some sparkle effect when the page loads
document.addEventListener('DOMContentLoaded', function() {
    // Create floating particles
    createFloatingParticles();
    
    // Add a welcome console message
    console.log('🌍 Hello World page loaded successfully!');
    console.log('💻 Welcome to your coding journey!');
});

function createFloatingParticles() {
    const container = document.querySelector('.container');
    
    for (let i = 0; i < 6; i++) {
        setTimeout(() => {
            const particle = document.createElement('div');
            particle.style.cssText = `
                position: absolute;
                width: 4px;
                height: 4px;
                background: rgba(255, 255, 255, 0.8);
                border-radius: 50%;
                pointer-events: none;
                animation: float 3s ease-in-out infinite;
                animation-delay: ${i * 0.5}s;
                left: ${Math.random() * 100}%;
                top: ${Math.random() * 100}%;
            `;
            
            container.appendChild(particle);
            
            // Remove particle after animation
            setTimeout(() => {
                if (particle.parentNode) {
                    particle.parentNode.removeChild(particle);
                }
            }, 3000);
        }, i * 500);
    }
}

// Add CSS for floating animation
const style = document.createElement('style');
style.textContent = `
    @keyframes float {
        0%, 100% {
            transform: translateY(0px) rotate(0deg);
            opacity: 0;
        }
        50% {
            transform: translateY(-20px) rotate(180deg);
            opacity: 1;
        }
    }
`;
document.head.appendChild(style);
