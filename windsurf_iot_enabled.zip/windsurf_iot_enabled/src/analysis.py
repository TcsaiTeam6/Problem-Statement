import pandas as pd
import numpy as np
from typing import Dict, List, Tuple


def load_data(
    energy_logs_path: str,
    device_metadata_path: str,
    schedules_path: str,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Load CSV files and parse timestamps.
    Expected schemas:
      - energy_logs: timestamp, device_id, energy_kwh
      - device_metadata: device_id, device_type, location, standby_kwh
      - operational_schedules: device_id, weekday, start_hour, end_hour
    """
    logs = pd.read_csv(energy_logs_path)
    logs['timestamp'] = pd.to_datetime(logs['timestamp'])
    logs['hour'] = logs['timestamp'].dt.hour
    logs['weekday'] = logs['timestamp'].dt.day_name()

    meta = pd.read_csv(device_metadata_path)
    schedules = pd.read_csv(schedules_path)
    return logs, meta, schedules


def expand_weekday_schedule(row: pd.Series) -> List[str]:
    mapping = {
        'Mon-Fri': ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
        'Mon-Sat': ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
        'Mon-Sun': ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
        'Weekend': ['Saturday', 'Sunday'],
    }
    wk = str(row['weekday'])
    if wk in mapping:
        return mapping[wk]
    return [wk]


def compute_kpis(logs: pd.DataFrame) -> Dict[str, float]:
    total_kwh = float(logs['energy_kwh'].sum())
    avg_kwh_per_device = float(logs.groupby('device_id')['energy_kwh'].sum().mean()) if not logs.empty else 0.0
    peak_hour = int(logs.groupby('hour')['energy_kwh'].sum().idxmax()) if not logs.empty else -1
    peak_hour_kwh = float(logs.groupby('hour')['energy_kwh'].sum().max()) if not logs.empty else 0.0
    return {
        'total_kwh': total_kwh,
        'avg_kwh_per_device': avg_kwh_per_device,
        'peak_hour': peak_hour,
        'peak_hour_kwh': peak_hour_kwh,
    }


def detect_off_schedule_usage(
    logs: pd.DataFrame,
    schedules: pd.DataFrame,
) -> pd.DataFrame:
    """Find energy consumed outside scheduled hours for each device/day."""
    # Build schedule lookup
    sched_rows = []
    for _, r in schedules.iterrows():
        days = expand_weekday_schedule(r)
        for d in days:
            sched_rows.append({
                'device_id': r['device_id'],
                'weekday': d,
                'start_hour': int(r['start_hour']),
                'end_hour': int(r['end_hour']),
            })
    sched_df = pd.DataFrame(sched_rows)

    logs2 = logs.copy()
    logs2['hour'] = logs2['timestamp'].dt.hour
    logs2['weekday'] = logs2['timestamp'].dt.day_name()

    merged = logs2.merge(sched_df, on=['device_id', 'weekday'], how='left')
    # If schedule missing, consider everything off-schedule to surface gaps
    cond_missing = merged['start_hour'].isna()
    cond_off_before = merged['hour'] < merged['start_hour']
    cond_off_after = merged['hour'] >= merged['end_hour']
    off_sched = merged[cond_missing | cond_off_before | cond_off_after]

    return off_sched[['timestamp', 'device_id', 'weekday', 'hour', 'energy_kwh', 'start_hour', 'end_hour']]


def estimate_standby_waste(
    logs: pd.DataFrame,
    meta: pd.DataFrame,
) -> pd.DataFrame:
    """Estimate standby waste by comparing low-usage periods to device standby baseline."""
    # Join metadata
    df = logs.merge(meta[['device_id', 'standby_kwh']], on='device_id', how='left')
    # Consider hours with low consumption close to standby as potential waste periods
    df['waste_kwh'] = np.where(df['energy_kwh'] <= df['standby_kwh'] * 1.2, df['energy_kwh'], 0.0)
    waste_by_device = df.groupby('device_id', as_index=False).agg(
        total_waste_kwh=('waste_kwh', 'sum'),
        total_kwh=('energy_kwh', 'sum')
    )
    waste_by_device['waste_pct'] = np.where(
        waste_by_device['total_kwh'] > 0,
        (waste_by_device['total_waste_kwh'] / waste_by_device['total_kwh']) * 100.0,
        0.0
    )
    return waste_by_device.sort_values('total_waste_kwh', ascending=False)


def detect_anomalies_zscore(logs: pd.DataFrame, threshold: float = 2.0) -> pd.DataFrame:
    """Simple anomaly detection per device by z-score across its readings."""
    def zscore(g: pd.DataFrame) -> pd.DataFrame:
        mu = g['energy_kwh'].mean()
        sigma = g['energy_kwh'].std(ddof=0) or 1e-9
        g = g.copy()
        g['z'] = (g['energy_kwh'] - mu) / sigma
        return g

    z = logs.groupby('device_id', group_keys=False).apply(zscore)
    anomalies = z[np.abs(z['z']) >= threshold]
    return anomalies[['timestamp', 'device_id', 'energy_kwh', 'z']].sort_values(['device_id', 'timestamp'])


def build_text_report(
    energy_df: pd.DataFrame,
    devices_df: pd.DataFrame,
    schedules_df: pd.DataFrame,
) -> str:
    """Build a comprehensive text report"""
    report = []
    
    # Header
    report.append("=" * 80)
    report.append("HARSHA MOTORS - COMPREHENSIVE ENERGY ANALYSIS REPORT")
    report.append("=" * 80)
    report.append(f"Report Generated: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append(f"Analysis Period: {energy_df['timestamp'].min().strftime('%Y-%m-%d')} to {energy_df['timestamp'].max().strftime('%Y-%m-%d')}")
    report.append("")
    
    # Executive Summary
    total_consumption = energy_df['energy_kwh'].sum()
    avg_consumption = energy_df['energy_kwh'].mean()
    device_count = energy_df['device_id'].nunique()
    dept_count = energy_df['department'].nunique()
    
    report.append("EXECUTIVE SUMMARY")
    report.append("-" * 40)
    report.append(f"• Total Energy Consumption: {total_consumption:,.2f} kWh")
    report.append(f"• Average Hourly Consumption: {avg_consumption:.2f} kWh")
    report.append(f"• Number of Monitored Devices: {device_count}")
    report.append(f"• Number of Departments: {dept_count}")
    report.append(f"• Estimated Total Cost: ${total_consumption * 100:,.2f} (@ $100/kWh)")
    report.append("")
    
    # Department Analysis
    dept_consumption = energy_df.groupby('department')['energy_kwh'].sum().sort_values(ascending=False)
    report.append("DEPARTMENT-WISE ENERGY CONSUMPTION")
    report.append("-" * 40)
    for i, (dept, consumption) in enumerate(dept_consumption.items(), 1):
        percentage = (consumption / total_consumption) * 100
        report.append(f"{i}. {dept}: {consumption:,.2f} kWh ({percentage:.1f}%)")
    report.append("")
    
    # Top Energy Consumers
    top_devices = energy_df.groupby(['device_id', 'device_type', 'department'])['energy_kwh'].sum().sort_values(ascending=False).head(10)
    report.append("TOP 10 ENERGY CONSUMING DEVICES")
    report.append("-" * 40)
    for i, ((device_id, device_type, dept), consumption) in enumerate(top_devices.items(), 1):
        percentage = (consumption / total_consumption) * 100
        report.append(f"{i:2d}. {device_id} ({device_type}) - {dept}")
        report.append(f"     Consumption: {consumption:,.2f} kWh ({percentage:.1f}%)")
    report.append("")
    
    # Time-based Analysis
    hourly_avg = energy_df.groupby(energy_df['timestamp'].dt.hour)['energy_kwh'].mean()
    peak_hour = hourly_avg.idxmax()
    low_hour = hourly_avg.idxmin()
    
    report.append("TIME-BASED CONSUMPTION PATTERNS")
    report.append("-" * 40)
    report.append(f"• Peak Consumption Hour: {peak_hour}:00 ({hourly_avg[peak_hour]:.2f} kWh avg)")
    report.append(f"• Lowest Consumption Hour: {low_hour}:00 ({hourly_avg[low_hour]:.2f} kWh avg)")
    report.append(f"• Peak vs Low Difference: {((hourly_avg[peak_hour] - hourly_avg[low_hour]) / hourly_avg[low_hour] * 100):.1f}%")
    
    # Weekly patterns
    daily_avg = energy_df.groupby(energy_df['timestamp'].dt.day_name())['energy_kwh'].mean()
    weekday_avg = energy_df[energy_df['timestamp'].dt.weekday < 5]['energy_kwh'].mean()
    weekend_avg = energy_df[energy_df['timestamp'].dt.weekday >= 5]['energy_kwh'].mean()
    
    report.append(f"• Weekday Average: {weekday_avg:.2f} kWh")
    report.append(f"• Weekend Average: {weekend_avg:.2f} kWh")
    report.append(f"• Weekday vs Weekend Difference: {((weekday_avg - weekend_avg) / weekend_avg * 100):.1f}%")
    report.append("")
    
    # Device Type Analysis
    device_type_stats = energy_df.groupby('device_type')['energy_kwh'].agg(['sum', 'mean', 'count']).sort_values('sum', ascending=False)
    report.append("DEVICE TYPE ANALYSIS")
    report.append("-" * 40)
    for device_type, stats in device_type_stats.head(8).iterrows():
        report.append(f"• {device_type}:")
        report.append(f"  - Total Consumption: {stats['sum']:,.2f} kWh")
        report.append(f"  - Average per Device: {stats['mean']:.2f} kWh")
        report.append(f"  - Number of Devices: {stats['count']}")
    report.append("")
    
    # Efficiency Analysis
    report.append("ENERGY EFFICIENCY ANALYSIS")
    report.append("-" * 40)
    
    # Calculate efficiency metrics
    device_efficiency = energy_df.groupby('device_id')['energy_kwh'].agg(['mean', 'std']).fillna(0)
    device_efficiency['efficiency_score'] = 100 - (device_efficiency['std'] / device_efficiency['mean'] * 100).fillna(0)
    device_efficiency['efficiency_score'] = device_efficiency['efficiency_score'].clip(0, 100)
    
    high_efficiency = device_efficiency[device_efficiency['efficiency_score'] >= 80]
    low_efficiency = device_efficiency[device_efficiency['efficiency_score'] < 60]
    
    report.append(f"• High Efficiency Devices (Score ≥80): {len(high_efficiency)} devices")
    report.append(f"• Low Efficiency Devices (Score <60): {len(low_efficiency)} devices")
    report.append(f"• Average Efficiency Score: {device_efficiency['efficiency_score'].mean():.1f}%")
    report.append("")
    
    # Cost Analysis
    report.append("COST ANALYSIS & FINANCIAL IMPACT")
    report.append("-" * 40)
    monthly_cost = total_consumption * 100 / 6  # 6 months of data
    annual_projection = monthly_cost * 12
    
    report.append(f"• Estimated Monthly Energy Cost: ${monthly_cost:,.2f}")
    report.append(f"• Projected Annual Energy Cost: ${annual_projection:,.2f}")
    
    # Peak demand cost
    peak_demand = energy_df.groupby(energy_df['timestamp'].dt.date)['energy_kwh'].sum().max()
    peak_cost = peak_demand * 150  # Higher rate for peak demand
    report.append(f"• Peak Daily Consumption: {peak_demand:.2f} kWh")
    report.append(f"• Peak Demand Cost Impact: ${peak_cost:,.2f}/day")
    report.append("")
    
    # Optimization Recommendations
    report.append("ENERGY OPTIMIZATION RECOMMENDATIONS")
    report.append("-" * 40)
    
    # High-impact recommendations
    report.append("HIGH IMPACT RECOMMENDATIONS:")
    report.append("1. PEAK LOAD MANAGEMENT")
    potential_savings = (hourly_avg[peak_hour] - hourly_avg[low_hour]) * 30 * 100  # 30 days
    report.append(f"   • Shift non-critical operations from {peak_hour}:00 to {low_hour}:00")
    report.append(f"   • Potential Monthly Savings: ${potential_savings:,.2f}")
    report.append("")
    
    report.append("2. TOP CONSUMER OPTIMIZATION")
    top_3_consumption = top_devices.head(3).sum()
    optimization_potential = top_3_consumption * 0.15  # 15% improvement potential
    report.append(f"   • Focus on top 3 energy consumers ({top_3_consumption:,.2f} kWh total)")
    report.append(f"   • 15% efficiency improvement potential: {optimization_potential:,.2f} kWh")
    report.append(f"   • Estimated Annual Savings: ${optimization_potential * 2 * 100:,.2f}")
    report.append("")
    
    report.append("3. DEPARTMENT-LEVEL INITIATIVES")
    highest_dept = dept_consumption.index[0]
    highest_consumption = dept_consumption.iloc[0]
    report.append(f"   • Priority Department: {highest_dept} ({highest_consumption:,.2f} kWh)")
    report.append(f"   • Implement energy awareness programs")
    report.append(f"   • Install smart controls and automation")
    report.append("")
    
    # Medium-impact recommendations
    report.append("MEDIUM IMPACT RECOMMENDATIONS:")
    report.append("4. EQUIPMENT MAINTENANCE & UPGRADES")
    if len(low_efficiency) > 0:
        report.append(f"   • {len(low_efficiency)} devices show low efficiency (<60% score)")
        report.append("   • Schedule immediate maintenance inspection")
        report.append("   • Consider equipment upgrades for oldest devices")
    report.append("")
    
    report.append("5. OPERATIONAL SCHEDULING")
    report.append("   • Implement smart scheduling during off-peak hours")
    report.append("   • Coordinate department activities to balance load")
    report.append("   • Use predictive maintenance to avoid energy spikes")
    report.append("")
    
    # Monitoring and Control Recommendations
    report.append("MONITORING & CONTROL RECOMMENDATIONS:")
    report.append("6. REAL-TIME MONITORING ENHANCEMENTS")
    report.append("   • Set up automated alerts for consumption anomalies")
    report.append("   • Implement energy budgets per department")
    report.append("   • Create energy efficiency KPIs and dashboards")
    report.append("")
    
    report.append("7. PREDICTIVE ANALYTICS")
    report.append("   • Deploy machine learning for consumption forecasting")
    report.append("   • Implement predictive maintenance scheduling")
    report.append("   • Use weather data for HVAC optimization")
    report.append("")
    
    # ROI Analysis
    report.append("RETURN ON INVESTMENT (ROI) ANALYSIS")
    report.append("-" * 40)
    total_potential_savings = potential_savings * 12 + optimization_potential * 2 * 100
    implementation_cost = 50000  # Estimated implementation cost
    payback_period = implementation_cost / (total_potential_savings / 12)
    
    report.append(f"• Total Potential Annual Savings: ${total_potential_savings:,.2f}")
    report.append(f"• Estimated Implementation Cost: ${implementation_cost:,.2f}")
    report.append(f"• Payback Period: {payback_period:.1f} months")
    report.append(f"• 3-Year ROI: {((total_potential_savings * 3 - implementation_cost) / implementation_cost * 100):.1f}%")
    report.append("")
    
    # Action Plan
    report.append("IMMEDIATE ACTION PLAN (NEXT 30 DAYS)")
    report.append("-" * 40)
    report.append("Week 1-2:")
    report.append("• Conduct detailed audit of top 5 energy-consuming devices")
    report.append("• Implement peak hour load shifting for non-critical operations")
    report.append("• Set up automated monitoring alerts")
    report.append("")
    report.append("Week 3-4:")
    report.append("• Begin maintenance program for low-efficiency devices")
    report.append("• Train department heads on energy management best practices")
    report.append("• Establish energy efficiency targets and KPIs")
    report.append("")
    
    # Footer
    report.append("=" * 80)
    report.append("END OF REPORT")
    report.append("For questions or additional analysis, contact the Energy Management Team")
    report.append("=" * 80)
    
    return "\n".join(report)
    if not standby.empty:
        lines.append("Estimated Standby Waste (approx):")
        for _, r in standby.head(5).iterrows():
            lines.append(f" - {r['device_id']}: {r['total_waste_kwh']:.2f} kWh (~{r['waste_pct']:.1f}%)")
        lines.append("")

    # Anomalies
    if not anomalies.empty:
        lines.append(f"Anomalies detected: {len(anomalies)} readings beyond z-score ±2.0")
        examples = anomalies.head(5)
        for _, r in examples.iterrows():
            t = pd.to_datetime(r['timestamp']).strftime('%Y-%m-%d %H:%M')
            lines.append(f" - {r['device_id']} at {t}: {r['energy_kwh']:.2f} kWh (z={r['z']:.2f})")
        lines.append("")

    # Recommendations
    lines.append("Recommendations:")
    lines.append(" - Align device operations with schedules; investigate any off-schedule usage.")
    lines.append(" - Reduce standby consumption via smart plugs, sleep modes, and policy enforcement.")
    lines.append(" - Shift flexible loads away from peak hour to flatten demand.")
    lines.append(" - Investigate anomalies for potential faults or process deviations.")

    return "\n".join(lines)
