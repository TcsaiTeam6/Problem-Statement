import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

def generate_enhanced_data():
    """Generate 6 months of comprehensive IoT energy data for Harsha Motors"""
    
    # Date range: last 6 months
    end_date = datetime.now()
    start_date = end_date - timedelta(days=180)
    
    # Departments
    departments = [
        "Department 1", "Department 2", "Department 3", 
        "Department 4", "Department 5"
    ]
    
    # Device types with proper naming (no underscores, Init Caps)
    device_types = [
        {"type": "HVAC System", "base_consumption": 2.5, "variation": 1.0},
        {"type": "Lighting Panel", "base_consumption": 0.15, "variation": 0.05},
        {"type": "Motor Drive", "base_consumption": 1.8, "variation": 0.8},
        {"type": "Compressor Unit", "base_consumption": 3.2, "variation": 1.2},
        {"type": "Conveyor System", "base_consumption": 1.2, "variation": 0.4},
        {"type": "Welding Station", "base_consumption": 4.5, "variation": 2.0},
        {"type": "CNC Machine", "base_consumption": 6.0, "variation": 2.5},
        {"type": "Paint Booth", "base_consumption": 2.8, "variation": 1.0}
    ]
    
    # Generate devices
    devices = []
    device_id = 1
    for dept in departments:
        # Each department has 3-5 devices of different types
        num_devices = random.randint(3, 5)
        dept_devices = random.sample(device_types, min(num_devices, len(device_types)))
        
        for i, device_info in enumerate(dept_devices):
            devices.append({
                "device_id": f"{device_info['type'].replace(' ', '')}_{device_id:03d}",
                "device_type": device_info['type'],
                "department": dept,
                "location": f"{dept} - Zone {chr(65+i)}",
                "standby_kwh": device_info['base_consumption'] * 0.3,
                "base_consumption": device_info['base_consumption'],
                "variation": device_info['variation']
            })
            device_id += 1
    
    # Generate energy logs
    energy_logs = []
    current_date = start_date
    
    while current_date <= end_date:
        for device in devices:
            # Generate hourly data for each device
            for hour in range(24):
                timestamp = current_date.replace(hour=hour, minute=0, second=0)
                
                # Base consumption with patterns
                base = device['base_consumption']
                variation = device['variation']
                
                # Time-based patterns
                hour_factor = 1.0
                if 6 <= hour <= 18:  # Working hours
                    hour_factor = 1.0 + (0.3 * np.sin((hour - 6) * np.pi / 12))
                else:  # Off hours
                    hour_factor = 0.3 + 0.2 * random.random()
                
                # Day of week pattern
                weekday_factor = 1.0
                if current_date.weekday() >= 5:  # Weekend
                    weekday_factor = 0.4
                
                # Seasonal pattern (higher in summer/winter for HVAC)
                month = current_date.month
                seasonal_factor = 1.0
                if device['device_type'] == 'HVAC System':
                    if month in [6, 7, 8, 12, 1, 2]:  # Summer/Winter
                        seasonal_factor = 1.4
                    else:
                        seasonal_factor = 0.8
                
                # Recent trend (some devices consuming more lately)
                trend_factor = 1.0
                days_from_start = (current_date - start_date).days
                if device['device_id'].endswith(('001', '005', '008')):  # Some devices trending up
                    trend_factor = 1.0 + (days_from_start / 180) * 0.3
                
                # Calculate final consumption
                consumption = (base * hour_factor * weekday_factor * 
                             seasonal_factor * trend_factor * 
                             (1 + random.gauss(0, 0.1)))
                
                # Ensure minimum consumption (standby)
                consumption = max(consumption, device['standby_kwh'])
                
                energy_logs.append({
                    "timestamp": timestamp,
                    "device_id": device['device_id'],
                    "energy_kwh": round(consumption, 3),
                    "department": device['department'],
                    "device_type": device['device_type'],
                    "location": device['location']
                })
        
        current_date += timedelta(days=1)
    
    # Generate operational schedules
    schedules = []
    for device in devices:
        # Most devices operate during business hours
        if device['device_type'] in ['Lighting Panel']:
            start_hour, end_hour = 6, 22
        elif device['device_type'] in ['HVAC System']:
            start_hour, end_hour = 7, 19
        else:
            start_hour, end_hour = 8, 18
            
        schedules.append({
            "device_id": device['device_id'],
            "weekday": "Mon-Fri",
            "start_hour": start_hour,
            "end_hour": end_hour
        })
    
    # Convert to DataFrames with proper data types
    energy_df = pd.DataFrame(energy_logs)
    devices_df = pd.DataFrame(devices)
    schedules_df = pd.DataFrame(schedules)
    
    # Ensure timestamp is properly formatted
    energy_df['timestamp'] = pd.to_datetime(energy_df['timestamp'])
    
    # Ensure numeric columns are properly typed
    energy_df['energy_kwh'] = pd.to_numeric(energy_df['energy_kwh'], errors='coerce')
    devices_df['standby_kwh'] = pd.to_numeric(devices_df['standby_kwh'], errors='coerce')
    
    # Ensure string columns are properly typed
    for col in ['device_id', 'department', 'device_type', 'location']:
        if col in energy_df.columns:
            energy_df[col] = energy_df[col].astype(str)
        if col in devices_df.columns:
            devices_df[col] = devices_df[col].astype(str)
    
    return energy_df, devices_df, schedules_df

def save_enhanced_data():
    """Generate and save enhanced data to CSV files"""
    energy_df, devices_df, schedules_df = generate_enhanced_data()
    
    # Save to CSV files
    energy_df.to_csv("data/energy_logs_enhanced.csv", index=False)
    devices_df[['device_id', 'device_type', 'location', 'standby_kwh', 'department']].to_csv(
        "data/device_metadata_enhanced.csv", index=False)
    schedules_df.to_csv("data/operational_schedules_enhanced.csv", index=False)
    
    return energy_df, devices_df, schedules_df

if __name__ == "__main__":
    save_enhanced_data()
    print("Enhanced data generated successfully!")
