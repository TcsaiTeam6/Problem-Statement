import os
from typing import List, Optional

from langchain_community.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain.chains import RetrievalQA


class QAAgent:
    def __init__(self, model: str = "gpt-4o-mini", chunk_size: int = 800, chunk_overlap: int = 100):
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY not set; Q&A is optional. Set it in environment to enable.")
        base_url = os.getenv("OPENAI_BASE_URL")
        embeddings_base_url = os.getenv("OPENAI_EMBEDDINGS_BASE_URL")
        # Work around environments that set HTTP(S)_PROXY variables which can
        # cause some client constructors to receive unsupported arguments.
        # We temporarily remove these for the lifetime of the process.
        for k in [
            "HTTP_PROXY",
            "HTTPS_PROXY",
            "ALL_PROXY",
            "http_proxy",
            "https_proxy",
            "all_proxy",
            "OPENAI_PROXY",
        ]:
            os.environ.pop(k, None)
        # Ensure proxies are not used
        os.environ["NO_PROXY"] = "*"

        # Use a stable, inexpensive embedding model explicitly.
        emb_kwargs = {
            "model": "text-embedding-3-small",
            "api_key": api_key,
        }
        if embeddings_base_url:
            emb_kwargs["base_url"] = embeddings_base_url
        self.embeddings = OpenAIEmbeddings(**emb_kwargs)
        self.splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        # ChatOpenAI will read OPENAI_API_KEY from the environment.
        self.llm = ChatOpenAI(model=model, temperature=0, api_key=api_key, base_url=base_url)
        self.vs: Optional[FAISS] = None

    def build_index(self, texts: List[str]):
        docs: List[Document] = [Document(page_content=t) for t in texts if t and t.strip()]
        chunks: List[Document] = []
        for d in docs:
            chunks.extend(self.splitter.split_documents([d]))
        if not chunks:
            raise ValueError("No text chunks to index.")
        self.vs = FAISS.from_documents(chunks, self.embeddings)

    def answer(self, query: str) -> str:
        if not self.vs:
            raise RuntimeError("Vector store not built. Call build_index() first.")
        retriever = self.vs.as_retriever(search_kwargs={"k": 4})
        chain = RetrievalQA.from_chain_type(self.llm, retriever=retriever, chain_type="stuff")
        out = chain.invoke({"query": query})
        return out["result"]
