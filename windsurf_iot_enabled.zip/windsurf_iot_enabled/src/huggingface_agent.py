import os
import pandas as pd
import streamlit as st
from typing import List, Dict, Any
import json
import requests

try:
    from transformers import pipeline, AutoTokenizer, AutoModelForCausalLM
    from sentence_transformers import SentenceTransformer
    import torch
    HF_AVAILABLE = True
except ImportError:
    HF_AVAILABLE = False

class HuggingFaceAPIAgent:
    def __init__(self, api_key: str, model_name: str = "meta-llama/Llama-2-7b-chat-hf"):
        """Initialize Hugging Face API agent with Llama 3"""
        self.api_key = api_key
        self.model_name = model_name
        self.api_url = f"https://api-inference.huggingface.co/models/{model_name}"
        self.headers = {"Authorization": f"Bearer {api_key}"}
        self.context_data = ""
        
        if not api_key:
            raise RuntimeError("Hugging Face API key is required")
    
    def set_context(self, energy_df: pd.DataFrame, devices_df: pd.DataFrame):
        """Set the energy data context for Q&A"""
        try:
            # Create a comprehensive context from the data
            context_parts = []
            
            # Summary statistics
            total_consumption = energy_df['energy_kwh'].sum()
            avg_consumption = energy_df['energy_kwh'].mean()
            device_count = energy_df['device_id'].nunique()
            dept_count = energy_df['department'].nunique()
            
            context_parts.append(f"Harsha Motors Energy Data Summary:")
            context_parts.append(f"- Total energy consumption: {total_consumption:.2f} kWh")
            context_parts.append(f"- Average consumption per reading: {avg_consumption:.2f} kWh")
            context_parts.append(f"- Number of devices monitored: {device_count}")
            context_parts.append(f"- Number of departments: {dept_count}")
            
            # Top consuming devices
            top_devices = energy_df.groupby('device_id')['energy_kwh'].sum().nlargest(5)
            context_parts.append(f"Top 5 energy consuming devices:")
            for i, (device, consumption) in enumerate(top_devices.items(), 1):
                context_parts.append(f"  {i}. {device}: {consumption:.2f} kWh")
            
            # Department breakdown
            dept_consumption = energy_df.groupby('department')['energy_kwh'].sum().sort_values(ascending=False)
            context_parts.append(f"Energy consumption by department:")
            for dept, consumption in dept_consumption.items():
                context_parts.append(f"  - {dept}: {consumption:.2f} kWh")
            
            # Time patterns
            hourly_avg = energy_df.groupby(energy_df['timestamp'].dt.hour)['energy_kwh'].mean()
            peak_hour = hourly_avg.idxmax()
            low_hour = hourly_avg.idxmin()
            context_parts.append(f"Time patterns:")
            context_parts.append(f"  - Peak consumption hour: {peak_hour}:00 ({hourly_avg[peak_hour]:.2f} kWh avg)")
            context_parts.append(f"  - Lowest consumption hour: {low_hour}:00 ({hourly_avg[low_hour]:.2f} kWh avg)")
            
            # Device types
            device_types = energy_df['device_type'].value_counts()
            context_parts.append(f"Device types in the facility:")
            for dtype, count in device_types.head(5).items():
                avg_consumption_by_type = energy_df[energy_df['device_type'] == dtype]['energy_kwh'].mean()
                context_parts.append(f"  - {dtype}: {count} devices (avg: {avg_consumption_by_type:.2f} kWh)")
            
            # Recent trends (if data spans multiple days)
            if energy_df['timestamp'].dt.date.nunique() > 7:
                recent_week = energy_df[energy_df['timestamp'] >= energy_df['timestamp'].max() - pd.Timedelta(days=7)]
                prev_week = energy_df[
                    (energy_df['timestamp'] >= energy_df['timestamp'].max() - pd.Timedelta(days=14)) &
                    (energy_df['timestamp'] < energy_df['timestamp'].max() - pd.Timedelta(days=7))
                ]
                if not prev_week.empty:
                    recent_avg = recent_week['energy_kwh'].mean()
                    prev_avg = prev_week['energy_kwh'].mean()
                    change_pct = ((recent_avg - prev_avg) / prev_avg) * 100
                    context_parts.append(f"Recent trend: Energy consumption has {'increased' if change_pct > 0 else 'decreased'} by {abs(change_pct):.1f}% in the last week")
            
            self.context_data = "\n".join(context_parts)
            
        except Exception as e:
            st.error(f"Error setting context: {str(e)}")
            self.context_data = "Harsha Motors energy monitoring system with multiple devices across different departments."
    
    def answer_question(self, question: str) -> str:
        """Answer a question using Hugging Face API"""
        try:
            # Create a detailed prompt for Llama
            prompt = f"""You are an AI-powered chatbot and energy analyst for Harsha Motors' Energy Intelligence Dashboard. You help users understand and optimize their IoT energy consumption data through natural language Q&A.

CONTEXT: You are integrated into a comprehensive energy management dashboard that monitors IoT devices across 5 departments in a manufacturing facility. Users can ask you questions about energy consumption patterns, optimization opportunities, cost analysis, and operational insights.

ENERGY DATA CONTEXT:
{self.context_data}

USER QUESTION: {question}

Please provide a detailed, professional response that:
1. Directly answers the question using the provided energy data
2. Includes specific numbers, metrics, and percentages where relevant
3. Provides actionable recommendations and optimization strategies
4. References dashboard features when appropriate (charts, filters, drill-down capabilities)
5. Uses a professional but conversational tone suitable for business users
6. Focuses on practical insights that can drive energy efficiency improvements

RESPONSE:"""

            # Make API request
            payload = {
                "inputs": prompt,
                "parameters": {
                    "max_new_tokens": 500,
                    "temperature": 0.7,
                    "top_p": 0.9,
                    "do_sample": True,
                    "return_full_text": False
                }
            }
            
            response = requests.post(self.api_url, headers=self.headers, json=payload)
            
            if response.status_code == 200:
                result = response.json()
                if isinstance(result, list) and len(result) > 0:
                    answer = result[0].get('generated_text', '').strip()
                    # Clean up the response
                    if answer:
                        # Remove the prompt if it's included in the response
                        if "RESPONSE:" in answer:
                            answer = answer.split("RESPONSE:")[-1].strip()
                        return answer
                    else:
                        return self._fallback_answer(question)
                else:
                    return self._fallback_answer(question)
            else:
                st.warning(f"API request failed with status {response.status_code}. Using fallback response.")
                return self._fallback_answer(question)
                
        except Exception as e:
            st.error(f"Error with Hugging Face API: {str(e)}")
            return self._fallback_answer(question)
    
    def _fallback_answer(self, question: str) -> str:
        """Enhanced fallback answers with context data"""
        question_lower = question.lower()
        
        if not self.context_data:
            return "I need energy data context to provide accurate answers. Please ensure the data is loaded properly."
        
        # Parse context for intelligent responses
        lines = self.context_data.split('\n')
        
        if any(word in question_lower for word in ['highest', 'most', 'maximum', 'top']):
            if 'device' in question_lower:
                # Find top device from context
                for line in lines:
                    if "1." in line and ":" in line:
                        device_info = line.split("1.")[1].strip()
                        return f"Based on the current data analysis, {device_info} is the highest energy consuming device. You can see the complete ranking in the 'Top 10 Energy Consuming Devices' chart in the dashboard."
            elif 'department' in question_lower:
                for line in lines:
                    if line.strip().startswith("- Department") and ":" in line:
                        dept_info = line.strip()[2:]  # Remove "- "
                        return f"The highest consuming department is {dept_info}. Check the department breakdown pie chart for a complete comparison."
        
        elif any(word in question_lower for word in ['peak', 'hour', 'time']):
            for line in lines:
                if "Peak consumption hour:" in line:
                    peak_info = line.split("Peak consumption hour:")[1].strip()
                    return f"Peak consumption occurs at {peak_info}. This information can help you optimize energy usage by scheduling high-consumption activities during off-peak hours."
        
        elif any(word in question_lower for word in ['total', 'consumption']):
            for line in lines:
                if "Total energy consumption:" in line:
                    total_info = line.split("Total energy consumption:")[1].strip()
                    return f"The total energy consumption across all monitored devices is {total_info}. This represents the complete energy footprint of your facility."
        
        elif any(word in question_lower for word in ['save', 'reduce', 'optimize', 'efficiency']):
            return """Based on the energy data analysis, here are key recommendations to reduce energy consumption:

1. **Peak Hour Management**: Shift non-critical operations away from peak consumption hours
2. **Device Optimization**: Focus on the top energy-consuming devices for efficiency improvements
3. **Departmental Analysis**: Implement energy-saving measures in the highest-consuming departments
4. **Scheduled Operations**: Use the hourly consumption patterns to optimize equipment scheduling
5. **Regular Monitoring**: Set up alerts for unusual consumption spikes

Check the 'Actionable Insights' section for specific devices showing increasing energy trends."""
        
        else:
            return f"""I can help you analyze Harsha Motors' energy consumption data. Based on the current dataset, I can provide insights about:

• Energy consumption patterns across {self.context_data.count('Department')} departments
• Performance analysis of individual devices and equipment
• Peak usage hours and optimization opportunities
• Cost analysis and energy saving recommendations
• Trend analysis and anomaly detection

Try asking specific questions about energy consumption, device performance, or optimization strategies."""

class HuggingFaceLlamaAgent:
    def __init__(self, model_name: str = "microsoft/DialoGPT-medium"):
        """Initialize Hugging Face Llama agent with fallback to lighter model"""
        self.model_name = model_name
        self.qa_pipeline = None
        self.embeddings_model = None
        self.context_data = ""
        
        if not HF_AVAILABLE:
            raise RuntimeError("Hugging Face transformers not available. Install with: pip install transformers torch sentence-transformers")
        
        self._initialize_models()
    
    def _initialize_models(self):
        """Initialize the models with error handling"""
        try:
            # Use a lighter model for demo purposes (DialoGPT or DistilBERT)
            # For production, you could use "meta-llama/Llama-2-7b-chat-hf" with proper authentication
            
            # Initialize text generation pipeline
            device = 0 if torch.cuda.is_available() else -1
            
            # Use a conversational model that works well for Q&A
            self.qa_pipeline = pipeline(
                "text-generation",
                model="microsoft/DialoGPT-small",  # Lighter model for demo
                device=device,
                max_length=512,
                do_sample=True,
                temperature=0.7,
                pad_token_id=50256
            )
            
            # Initialize embeddings model for context similarity
            self.embeddings_model = SentenceTransformer('all-MiniLM-L6-v2')
            
        except Exception as e:
            st.error(f"Error initializing Hugging Face models: {str(e)}")
            # Fallback to a simple rule-based system
            self.qa_pipeline = None
            self.embeddings_model = None
    
    def set_context(self, energy_df: pd.DataFrame, devices_df: pd.DataFrame):
        """Set the energy data context for Q&A"""
        try:
            # Create a comprehensive context from the data
            context_parts = []
            
            # Summary statistics
            total_consumption = energy_df['energy_kwh'].sum()
            avg_consumption = energy_df['energy_kwh'].mean()
            device_count = energy_df['device_id'].nunique()
            dept_count = energy_df['department'].nunique()
            
            context_parts.append(f"Energy Data Summary: Total consumption is {total_consumption:.2f} kWh across {device_count} devices in {dept_count} departments. Average consumption is {avg_consumption:.2f} kWh per reading.")
            
            # Top consuming devices
            top_devices = energy_df.groupby('device_id')['energy_kwh'].sum().nlargest(5)
            context_parts.append(f"Top consuming devices: {', '.join([f'{dev}: {cons:.2f} kWh' for dev, cons in top_devices.items()])}")
            
            # Department breakdown
            dept_consumption = energy_df.groupby('department')['energy_kwh'].sum()
            context_parts.append(f"Department consumption: {', '.join([f'{dept}: {cons:.2f} kWh' for dept, cons in dept_consumption.items()])}")
            
            # Time patterns
            hourly_avg = energy_df.groupby(energy_df['timestamp'].dt.hour)['energy_kwh'].mean()
            peak_hour = hourly_avg.idxmax()
            context_parts.append(f"Peak consumption hour: {peak_hour}:00 with {hourly_avg[peak_hour]:.2f} kWh average")
            
            # Device types
            device_types = energy_df['device_type'].value_counts()
            context_parts.append(f"Device types: {', '.join([f'{dtype}: {count} devices' for dtype, count in device_types.head(5).items()])}")
            
            self.context_data = " ".join(context_parts)
            
        except Exception as e:
            st.error(f"Error setting context: {str(e)}")
            self.context_data = "Energy monitoring system with multiple devices and departments."
    
    def answer_question(self, question: str) -> str:
        """Answer a question about the energy data"""
        if not self.qa_pipeline:
            return self._fallback_answer(question)
        
        try:
            # Prepare the prompt with context
            prompt = f"""Context: {self.context_data}

Question: {question}

Answer: Based on the energy data,"""
            
            # Generate response
            response = self.qa_pipeline(
                prompt,
                max_length=len(prompt) + 100,
                num_return_sequences=1,
                temperature=0.7,
                do_sample=True,
                pad_token_id=50256
            )
            
            # Extract the answer part
            full_response = response[0]['generated_text']
            answer = full_response[len(prompt):].strip()
            
            # Clean up the answer
            if not answer:
                return self._fallback_answer(question)
            
            return answer
            
        except Exception as e:
            st.error(f"Error generating answer: {str(e)}")
            return self._fallback_answer(question)
    
    def _fallback_answer(self, question: str) -> str:
        """Provide rule-based answers when AI model fails"""
        question_lower = question.lower()
        
        # Simple keyword-based responses
        if any(word in question_lower for word in ['highest', 'most', 'maximum', 'top']):
            if 'device' in question_lower:
                return "Based on the data analysis, you can check the 'Top 10 Energy Consuming Devices' chart in the dashboard to see which devices consume the most energy."
            elif 'department' in question_lower:
                return "The department consumption breakdown is shown in the pie chart. Department consumption varies based on the number and type of devices in each department."
        
        elif any(word in question_lower for word in ['lowest', 'least', 'minimum']):
            return "To find the lowest consuming devices or departments, look at the bottom of the consumption charts or use the detailed data view with sorting options."
        
        elif any(word in question_lower for word in ['peak', 'hour', 'time']):
            return "Peak consumption typically occurs during business hours (8 AM - 6 PM). Check the seasonality analysis section for detailed hourly and daily patterns."
        
        elif any(word in question_lower for word in ['save', 'reduce', 'optimize']):
            return "Check the 'Actionable Insights' section for specific recommendations on reducing energy consumption. Focus on devices showing increasing trends and off-schedule usage."
        
        elif any(word in question_lower for word in ['cost', 'money', 'dollar', '$']):
            return "Use the kWh/$ toggle in the sidebar to view consumption in dollar values. The conversion rate is $100 per kWh as configured."
        
        else:
            return f"I can help you analyze the energy data. Try asking about top consuming devices, peak hours, department comparisons, or energy saving opportunities. You can also explore the interactive charts and filters in the dashboard."

# Simplified Q&A interface for when full HF models aren't available
class SimpleQAAgent:
    def __init__(self):
        self.context_data = {}
    
    def set_context(self, energy_df: pd.DataFrame, devices_df: pd.DataFrame):
        """Set context with processed data"""
        self.context_data = {
            'total_consumption': energy_df['energy_kwh'].sum(),
            'device_count': energy_df['device_id'].nunique(),
            'top_devices': energy_df.groupby('device_id')['energy_kwh'].sum().nlargest(5).to_dict(),
            'dept_consumption': energy_df.groupby('department')['energy_kwh'].sum().to_dict(),
            'peak_hour': energy_df.groupby(energy_df['timestamp'].dt.hour)['energy_kwh'].mean().idxmax()
        }
    
    def answer_question(self, question: str) -> str:
        """Provide data-driven answers"""
        question_lower = question.lower()
        
        if 'total' in question_lower and 'consumption' in question_lower:
            return f"Total energy consumption is {self.context_data.get('total_consumption', 0):.2f} kWh across {self.context_data.get('device_count', 0)} devices."
        
        elif 'top' in question_lower and 'device' in question_lower:
            top_devices = self.context_data.get('top_devices', {})
            if top_devices:
                device_list = [f"{dev}: {cons:.2f} kWh" for dev, cons in list(top_devices.items())[:3]]
                return f"Top consuming devices are: {', '.join(device_list)}"
        
        elif 'department' in question_lower:
            dept_data = self.context_data.get('dept_consumption', {})
            if dept_data:
                dept_list = [f"{dept}: {cons:.2f} kWh" for dept, cons in dept_data.items()]
                return f"Department consumption breakdown: {', '.join(dept_list)}"
        
        elif 'peak' in question_lower:
            peak_hour = self.context_data.get('peak_hour', 12)
            return f"Peak consumption typically occurs around {peak_hour}:00. Check the hourly consumption chart for detailed patterns."
        
        else:
            return "I can help you analyze energy consumption data. Try asking about total consumption, top devices, department breakdown, or peak hours."
