# ⚡ IoT Energy Consumption Optimization Agent

A runnable Streamlit app that analyzes IoT device energy usage, detects inefficiencies, and produces textual recommendations. Optional LLM Q&A (LangChain + OpenAI) allows you to ask natural-language questions about the results.

## Features
- KPI dashboard (total kWh, device averages, peak hour)
- Charts: time-series by device, total by device
- Off-schedule usage detection vs. operational schedules
- Standby waste estimation using device metadata
- Simple anomaly detection via z-score
- Textual report with optimization suggestions
- Optional Q&A over generated report (requires `OPENAI_API_KEY`)

## Project Structure
```
windsurf_iot_enabled/
├─ app.py                     # Streamlit app entrypoint
├─ requirements.txt           # Dependencies
├─ src/
│  ├─ __init__.py
│  ├─ analysis.py             # Core analytics and reporting
│  └─ agent.py                # Optional LangChain Q&A agent
├─ data/
│  ├─ energy_logs.csv         # Sample energy readings
│  ├─ device_metadata.csv     # Sample device metadata
│  └─ operational_schedules.csv # Sample operating schedules
└─ (hello world web files: index.html, styles.css, script.js)
```

## Install
1. Create and activate a Python 3.10+ environment.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Run
```bash
streamlit run app.py
```
This launches the app in your browser. Use the sidebar to upload your own CSVs or check "Use bundled sample data".

## Optional: Enable Q&A
Set your OpenAI API key before running the app:
```bash
# PowerShell (Windows)
$env:OPENAI_API_KEY="your_api_key_here"

# bash
export OPENAI_API_KEY="your_api_key_here"
```
Then restart the app. Open the Q&A expander and ask questions like:
- "Which device has the most off-schedule usage?"
- "How can I reduce standby waste?"

## Data Requirements
- energy_logs.csv: `timestamp, device_id, energy_kwh`
- device_metadata.csv: `device_id, device_type, location, standby_kwh`
- operational_schedules.csv: `device_id, weekday, start_hour, end_hour`
  - `weekday` supports single days (e.g., Monday) or ranges like `Mon-Fri`, `Mon-Sat`, `Mon-Sun`, `Weekend`.

## Notes
- Sample data is illustrative; replace with your real IoT data for meaningful insights.
- The analytics in `src/analysis.py` are modular—extend with tariff modeling, peak shifting simulation, or device-specific rules.
